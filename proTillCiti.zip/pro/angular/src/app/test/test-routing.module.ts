import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ComAComponent } from './com-a/com-a.component';
import { ComBComponent } from './com-b/com-b.component';
import { ComCComponent } from './com-c/com-c.component';
import { ButtonComponent } from './button/button.component';

const routes: Routes = [
  { path: "", component: ButtonComponent ,
  children:[
    { path: '' , component:ComAComponent},//comA
    { path: 'comB', component: ComBComponent},
    { path: "comC", component: ComCComponent }
  ]
}

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TestRoutingModule { }
