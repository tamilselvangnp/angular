import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.css']
})
export class ButtonComponent implements OnInit {

  constructor(public route: Router) { }

  ngOnInit() {
  }

  a=false; b=false; c=false;
  clickA(){
    this.a=true; this.b=false; this.c=false;
    this.route.navigate(['/test']);
  }
  clickB(){
    this.a=false; this.b=true; this.c=false;
    // this.route.navigate(['/test/comB']);
  }
  clickC(){
    this.a=false; this.b=false; this.c=true;
    // this.route.navigate(['/test/comC']);
  }

}
