import { Component, OnInit, DoCheck,OnChanges,AfterContentInit,AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy } from '@angular/core';
import * as CryptoJS from 'crypto-js';

@Component({
  selector: 'app-com-c',
  templateUrl: './com-c.component.html',
  styleUrls: ['./lss.less']
  // ./com-c.component.css
})
 export class ComCComponent implements OnInit,DoCheck,OnChanges,AfterContentInit,
 AfterContentChecked ,AfterViewInit,AfterViewChecked,OnDestroy{
check=false;
encryptMode;
textToConvert;
  constructor() { this.encryptMode =  true;console.log("constructor")}

  ngOnChanges(){console.log("ngOnChanges")}
  ngOnInit() {console.log("ngOnInit")}
  ngDoCheck() {console.log("ngDoCheck")}
  ngAfterContentInit() {console.log("ngAfterContentInit")}
  ngAfterContentChecked() {console.log("ngAfterContentChecked")}
  ngAfterViewInit() {console.log("ngAfterViewInit")}
  ngAfterViewChecked() {console.log("ngAfterViewChecked")}
  ngOnDestroy() {console.log("ngOnDestroy");alert("ngOnDestroy");}


  changeMode() {
    this.encryptMode = this.encryptMode ? false : true;
    this.textToConvert = "";
  }

  password="@#$%"
  conversionOutput;
  encryptModefun() {
    this.conversionOutput = CryptoJS.AES.encrypt(this.textToConvert.trim(), this.password.trim()).toString();
  }

  ncryptMode() {
  this.conversionOutput = CryptoJS.AES.decrypt(this.textToConvert.trim(), this.password.trim()).toString(CryptoJS.enc.Utf8);
  }

 }


// export class ComCComponent implements DoCheck {
//   ngDoCheck(): void {
//     throw new Error("Method not implemented.");
//   }
// }