import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-com-b',
  templateUrl: './com-b.component.html',
  styleUrls: ['./com-b.component.css']
})
export class ComBComponent implements OnInit {
  loader=false;
  constructor() {
    // this.Loader()
   }

  Loader(){
    this.loader=!this.loader;
    setTimeout (() => {
      this.loader=!this.loader;
      console.log("Hello from setTimeout");
   }, 3000); 
  }

  ngOnInit() {
  }

}
