import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { TestRoutingModule } from './test-routing.module';
import { ComAComponent } from './com-a/com-a.component';
import { ComBComponent } from './com-b/com-b.component';
import { ComCComponent } from './com-c/com-c.component';
import { ButtonComponent } from './button/button.component';


@NgModule({
  declarations: [ ComAComponent, ComBComponent, ComCComponent, ButtonComponent],
  imports: [
    CommonModule,TestRoutingModule,FormsModule
  ],
  bootstrap: [ButtonComponent]
})
export class TestModule { }
