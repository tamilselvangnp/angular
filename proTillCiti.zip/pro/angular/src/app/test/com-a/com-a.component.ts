import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-com-a',
  templateUrl: './com-a.component.html',
  styleUrls: ['./com-a.component.css']
})
export class ComAComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
