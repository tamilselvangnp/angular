import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl,Validators} from '@angular/forms';
import { DataService } from "../data.service";
import { Router } from "@angular/router";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  form1;
  constructor( public route: Router,private service: DataService) { }

  ngOnInit() {
    this.form1 = new FormGroup({
      userName: new FormControl("", [Validators.required]),
      password: new FormControl("", [Validators.required])
    });
  }

  users=["tamil","Bharath"];
  pass=["123","321"];
  flag=false;
  login(){
    console.log("form value",this.form1.value);
    for(let i=0;i<this.users.length;i++){
    if(this.form1.value.userName==this.users[i] && this.form1.value.password==this.pass[i]){
      this.flag=true;
    localStorage.setItem("user",this.form1.value.userName);
    // this.route.navigate(["/display"]);
    // this.route.navigate(['/display'], { state: { example: 'bar' } });
    this.route.navigate(['/display'], this.form1.value.userName);

    }
    }
  if(this.flag==false){
    alert("Enter correct credentials")
  }
  }


login1(){
  this.service.login(this.form1.value).subscribe(da => {
    if (da['msg']=="success") { 
      alert("Login Successfully");
      localStorage.setItem('token', da['token']);
      this.route.navigate(['/display'], this.form1.value.userName);
    } else {
      alert("Please try again");
    }
  });
}

logout(){
  this.service.logout();
}

}
