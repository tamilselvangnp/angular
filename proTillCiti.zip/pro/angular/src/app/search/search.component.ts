import { Component, OnInit } from '@angular/core';
import { DataService } from "../data.service";

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  city;
  SearchResults; rl=false; empty=false;start;
  constructor(private service: DataService) { 
  }
val; j=1;
  call(event: any){
    this.city = event.target.value;
    // console.log(this.city.length);
    if(this.city.trim().length>=3){ 
      this.SearchResults=undefined;  
      this.rl=true; this.empty=false; this.start=true;
      //data from node
      // if(this.city!=localStorage.getItem("key")){
      //   this.service.callDetails({val:this.city}).subscribe(db => {
      //     this.SearchResults=db
      //     console.log("goes to api")
      //     localStorage.setItem("key",this.city)
      //     // localStorage.setItem("SR",JSON.stringify(db))
      //     localStorage.setItem("SR",JSON.stringify(db))
      //     console.log("Mongo Details Add",db);
      //   });
      // }

      //data from url
      if(this.city.trim().toLowerCase()!=localStorage.getItem("key1") && this.city.trim().toLowerCase()!=localStorage.getItem("key2") 
       && this.city.trim().toLowerCase()!=localStorage.getItem("key3")  ){

        this.service.callDetails({val:this.city}).subscribe(db => { 
          var ArrayObject;    var string1=[];
          ArrayObject=db;     
          for(var i=0;i<ArrayObject.length;i++){
            // console.log("st",this.city.trim())
            if(ArrayObject[i].includes(this.city.trim().toLowerCase())){
             string1.push(ArrayObject[i])
            }
          }
          this.rl=false; if(string1.length==0){this.empty=true}
          this.SearchResults=string1; 
          console.log("goes to api",this.SearchResults)
          //
          var t1="key"+this.j;
          var t2="SR"+this.j;
          console.log("test value",t1,t2)
          //
          localStorage.setItem(t1,this.city.trim().toLowerCase())//"key"
          localStorage.setItem(t2,JSON.stringify(this.SearchResults))//"SR"
          // localStorage.setItem(this.city.trim().toLowerCase(),JSON.stringify(this.SearchResults))
          // localStorage.setItem("SR",JSON.stringify(db))

          //
          this.j++;
          if(this.j>3){this.j=1;}
          //
        });
      }
      else{
        this.rl=false;
        console.log("local storage")
        var key;
        for (let i = 1; i <= localStorage.length; i++){
          // console.log(localStorage.key(i),"key value",localStorage.getItem(localStorage.key(i)));
          if(this.city.trim().toLowerCase()==localStorage.getItem(localStorage.key(i))){
              var val=localStorage.key(i).charAt(3)
              key="SR"+val;
              console.log(key,"key value222");
              break;
          }
        }
        this.SearchResults=JSON.parse(localStorage.getItem(key) || "[]");
        if(this.SearchResults.length==0){this.empty=true}
        console.log(JSON.parse(localStorage.getItem(key) || "[]"))
      }
  }
  }  

  iden;idenRes;
//data in Node in Json file as Array
  // idCall(event: any){
  //   this.iden = event.target.value;
  //   this.service.identifData({val:this.iden}).subscribe(db => {
  //     this.idenRes=db
  //     // console.log("Mongo Details Add",db);
  //   });
  // }


//data in Angular as array
  idCall(event: any){
    var substring = this.iden;
    var ArrayObject=["tcs@gmail.com","tcs@tcs.com",
    "tamil#123","mouse&keyboard","*me","2^2=4",
    "this Book is worth of $10","L.H.S=R.H.S"];
    var string1=[];
    for(var i=0;i<ArrayObject.length;i++){
      if(ArrayObject[i].includes(substring)){
        var index=ArrayObject[i].indexOf(substring[substring.length-1])
        index=index+1
        string1.push(ArrayObject[i].slice(index))
      }
      else{
        string1.push(ArrayObject[i])
      }
    }
    this.idenRes=string1
  }

  ngOnInit() {
    this.start=false;
  }

}
