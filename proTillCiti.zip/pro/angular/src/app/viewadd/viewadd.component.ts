import { Component, OnInit } from '@angular/core';
import { DataService } from "../data.service";
import {FormGroup,FormControl,Validators} from '@angular/forms';

@Component({
  selector: 'app-viewadd',
  templateUrl: './viewadd.component.html',
  styleUrls: ['./viewadd.component.css']
})
export class ViewaddComponent implements OnInit {

  stuForm;
  namePattern="[A-Za-z]{3,32}";
  constructor(private service: DataService) { 
    this.stuForm = new FormGroup({
      name: new FormControl("", [Validators.required, Validators.pattern(this.namePattern)]),
      branch: new FormControl("", [Validators.required,Validators.pattern(this.namePattern)]),
      mark: new FormControl("", [Validators.required])
    });
  }

  ngOnInit() {
    this.view();
    this.service.mongoAdd().subscribe(db => {
      console.log("Mongo Details Add",db);
    });

    this.service.mongoView().subscribe(db => {
      console.log("Mongo Details View",db);
    });
  }

  viewData;
  view(){
    this.service.getAllDetails().subscribe(da => {
      console.log("View Details",da);
      this.viewData=da;
    });
    // console.log(this.sort_by_key(this.viewData, 'branch')) 
    // console.log(this.viewData.sort(this.GetSortOrder("name")))  

    //for testing Multiple http calls while loading a component
    this.service.getAllDetails().subscribe(da => {
      console.log("View Details 1111",da);
    });

    this.service.mongoView().subscribe(da => {
      console.log("View Details 222",da);
    });

    this.service.callDetails({ere:"ere"}).subscribe(da => {
      console.log("View Details 1111",da);
    });
    //******************************************************* */
  }


  GetDSortOrder(prop) {  
    return function(a, b) {  
        if (a[prop] < b[prop]) {  
            return 1;  
        } else if (a[prop] > b[prop]) {  
            return -1;  
        }  
        return 0;  
    }  
}  
 GetASortOrder(prop) {  
  return function(a, b) {  
      if (a[prop] > b[prop]) {  
          return 1;  
      } else if (a[prop] < b[prop]) {  
          return -1;  
      }  
      return 0;  
  }  
}   

fl=false;
sorti(data){
  this.fl=!this.fl;
  if(this.fl){
    this.viewData.sort(this.GetDSortOrder(data))
  }
  else{
    this.viewData.sort(this.GetASortOrder(data))
  }
}

sort_by_key(array, key)
{
 return array.sort(function(a, b)
 {
  var x = a[key]; var y = b[key];
  return ((x < y) ? -1 : ((x > y) ? 1 : 0));
 });
}

  submit(){
    console.log("Form Details",this.stuForm.value);

    this.service.addStuDetails(this.stuForm.value).subscribe(da => {
      if (da['msg']=="success") { 
        alert("Details Stored Successfully");
        this.view();
      } else {
        alert("Please try again");
      }
    });
  }

  flag=false;
  add(){
    this.flag=true;
  }

}
