import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl,Validators} from '@angular/forms';
import { Router } from "@angular/router";
import { DataService } from "../data.service";


@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
  user;
  routerextras;
  detailsForm;
  val;
  idPattern = "[0-9]{7}";   namePattern="[A-Za-z]{3,32}";
  constructor(public route: Router,private service: DataService) { 
    this.routerextras=this.route.getCurrentNavigation().extras
    console.log("route extras",this.route.getCurrentNavigation().extras);

    this.detailsForm = new FormGroup({
      empID: new FormControl("", [Validators.required, Validators.pattern(this.idPattern)]),
      empName: new FormControl("", [Validators.required,Validators.pattern(this.namePattern)]),
      dob: new FormControl("", [Validators.required])
    });
  }

  ngOnInit() {
    this.user=localStorage.getItem("user");
    console.log("in display component",this.user)
  }

  submit(){
    console.log("Form Details",this.detailsForm.value);
    this.val=JSON.stringify(this.detailsForm.value);

    this.service.send(this.detailsForm.value).subscribe(da => {
      if (da['msg']=="success") { 
        alert("Details Stored Successfully");
      } else {
        alert("Please try again");
      }
    });
  }

  onlyNumberKey(event) {
    return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
  }
  logout(){
    this.service.logout();
  }

}
