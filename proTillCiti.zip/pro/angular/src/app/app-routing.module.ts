import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component'
import { DisplayComponent } from './display/display.component';
import { ViewaddComponent } from './viewadd/viewadd.component';
import { SearchComponent } from './search/search.component';


const routes: Routes = [
  { path: "", component: HomeComponent },
  { path: "display", component: DisplayComponent },
  { path: "viewadd", component: ViewaddComponent },
  { path: "search", component: SearchComponent },
  {
    path: 'test',
    loadChildren: 'src/app/test/test.module#TestModule'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
