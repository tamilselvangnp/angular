import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Observable} from 'rxjs';
import 'rxjs/add/operator/map';
// import 'rxjs/add/operator/catch';
// import 'rxjs/add/observable/throw';
import { map } from "rxjs/operators";
import { Http } from "@angular/http";

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private http: HttpClient,private http1: Http) { }

  getAllDetails(): Observable<any>  {
    console.log("getAllDetails using call back");
    return this.http1.get("http://localhost:4500/getAllDetails", ).pipe(
      map(data => {
        return data.json();
      })
    );
  }


  login(data) {
    return this.http.post("http://localhost:4500/login", data, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    });
    }

    logout() {
      console.log("remove token")
      localStorage.removeItem('token');
    }
   
    public get logIn(): boolean {
      return (localStorage.getItem('token') !== null);
    }


//   private _postsURL = "https://api.myjson.com/bins/uaro7";
//   getPosts(): Observable<any> {
//     return this.http
//         .get(this._postsURL)
//         .map((response:any) => {
//           // console.log(response.json())
//             return response;
//         })
//         // .catch(this.handleError);
// }
// private handleError(error: Response) {
//   return Observable.throw(error.statusText);
// }

  send(userData) {
    console.log("users data", userData);
    return this.http.post('http://localhost:4500/send', userData, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    });
  }

  mongoAdd() {
    console.log("users data");
    var data={name:"Tamil", branch:"ECE", marks:"86.4"}
    return this.http.post('http://localhost:4500/default',data, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    });
  }

  mongoView() {
    console.log("users data");
    return this.http.get('http://localhost:4500/viewdetails', {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    });
  }

  addStuDetails(Data) {
    console.log("users data", Data);
    return this.http.post('http://localhost:4500/addStuDetails', Data, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    });
  }

  callDetails(Data) {
    console.log("filter1 data", Data);
    return this.http.get('https://api.myjson.com/bins/uaro7', {
    // return this.http.post('http://localhost:4500/filter1', Data, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    });
  }


  identifData(Data) {
    // console.log("filter1 data", Data);
    return this.http.post('http://localhost:4500/iden', Data, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    });
  }

  call(da) {
    console.log("call data",da);
    // return this.http.get('https://api.myjson.com/bins/uaro7', {
    return this.http.post('https://localhost:4500/filter1', da,{
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    });
  }

  // getAllDetails() {
  //   console.log("getAllDetails");
  //   return this.http.get('http://localhost:4500/getAllDetails', {
  //     headers: new HttpHeaders({
  //       'Content-Type': 'application/json',
  //     })
  //   });
  // }



//   getEventList(): Observable<any> {
//     let headers = new Headers({ 'Content-Type': 'application/json' });
//     let options = new RequestOptions({ headers: headers });
    
//     return this.http.get("http://localhost:4500/getAllDetails", options)
//                 .map((res)=>{ return res.json();})  //add call to json here
//                 .catch((err)=>{
//                   return err; //  console.error('error');
//                 })
//     }

//     getEventList1(postData): Observable<any> {
//     const httpOptions = {
//       headers: new HttpHeaders({
//         'Accept': 'application/x-www-form-urlencoded',
//         'Content-Type':  'application/json'
//         // 'Authorization': 'Basic' + btoa(username + ":" + password)
//       })
//     };
//  return this.http.post("http://localhost:4500/getAllDetails", postData, httpOptions ).map(res => res.json()).subscribe(
//     data => {
//       console.log(data);
//     },
//     err => {
//       console.log("ERROR!: ", err);
//     }
//   );
//   }

}
