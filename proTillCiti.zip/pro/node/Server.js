const http = require('http');
const express = require('express');
const app = express();
const bodyparser = require('body-parser');
app.use(bodyparser.json());
var port = 4500;
var hostName = "localhost";
var fs = require('fs');

const server = http.createServer(app);
app.use(function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
  res.setHeader('Access-Control-Allow-Credentials', true);
  next();
});


// for view Table Data*************************************

app.get('/getAllDetails', function (request, response, next) {
  console.log("in  get js");
  fs.createReadStream('studentData.json').pipe(response);
})


// for store empDetails in empDB.json**********************
app.post('/send', (request, response) => {
  console.log(request.body);
  fs.readFile('./empDB.json', function (err, data) {
    var ArrayObject = JSON.parse(data);
    ArrayObject.push(request.body);
    console.log(ArrayObject);
    var empDetails = JSON.stringify(ArrayObject)
    if (fs.existsSync('./empDB.json')) {
      fs.writeFile('./empDB.json', empDetails, 'utf8', (err) => {
        if (err) {
          response.status(201).send({msg:"Failed by writing"});
        } else {
          response.status(200).send({msg:"success"});
        }
      })
    } else {
      response.status(201).send({msg:"Failed by file doesn't exsist"});
    }
  });
  // response.status(200).send({msg:"success"});
});

//add Student Details**************************************
app.post('/addStuDetails', (request, response) => {
  console.log(request.body);
  fs.readFile('./studentData.json', function (err, data) {
    var ArrayObject = JSON.parse(data);
    ArrayObject.push(request.body);
    console.log(ArrayObject);
    var empDetails = JSON.stringify(ArrayObject)
    if (fs.existsSync('./studentData.json')) {
      fs.writeFile('./studentData.json', empDetails, 'utf8', (err) => {
        if (err) {
          response.status(201).send({msg:"Failed by writing"});
        } else {
          response.status(200).send({msg:"success"});
        }
      })
    } else {
      response.status(201).send({msg:"Failed by file doesn't exsist"});
    }
  });
  // response.status(200).send({msg:"success"});
});

//*********************************************************

server.listen(port, hostName, () => {
  console.log("Page is hosted in " + port + ' in ' + hostName);
});




// // Set up mongoose connection
// const mongoose = require('mongoose');
// let dev_db_url = 'mongodb://someuser:abcd1234@ds123619.mlab.com:23619/productstutorial';
// const mongoDB = process.env.MONGODB_URI || dev_db_url;
// // mongoose.connect(mongoDB);
// mongoose.connect('mongodb://localhost/testdb')
// mongoose.Promise = global.Promise;
// const db = mongoose.connection;
// db.on('error', console.error.bind(console, 'MongoDB connection error:'));

// var nameSchema = new mongoose.Schema({
//   firstName: String,
//   lastNameName: String
//  });

//  var User = mongoose.model("User", nameSchema);


//  app.post("/default", (req, res) => {
//   console.log("tesT item saved to database")
//   var myData = new User({name:"New User to Mongo DB"});
//   myData.save()
//   .then(item => {
//     console.log("item saved to database")
//   res.status(200).send({data:"item saved to database"});
//   })
//   .catch(err => {
//   res.status(201).send({data:"unable to save to database"});
//   });
//  });
