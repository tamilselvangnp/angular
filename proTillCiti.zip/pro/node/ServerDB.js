const http = require('http');
const express = require('express');
const cors=require('cors');
// const mongoose = require('mongoose');
var mongo = require('mongoose');
const app = express();
const bodyparser = require('body-parser');
app.use(bodyparser.json());
var port = 4500;
var hostName = "localhost";
var fs = require('fs');
const jwt = require('jsonwebtoken');

const server = http.createServer(app);
app.use(function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
  res.setHeader('Access-Control-Allow-Credentials', true);
  next();
});


// Set up mongoose connection
var db=mongo.connect("mongodb://localhost:27017/mydb", function(err,res){
    if(err){
        console.log(err);
    }
    else{
        console.log("connected to " +db +" " , res);
    }
} )

app.use(cors());
var Schema=mongo.Schema;
var UserSchema = new Schema({
    name:{type: String},
    branch:{type: String},
    marks:{type: String}
},{versionKey: false});


var model=mongo.model('users', UserSchema ,'users');

app.post('/default', function(req,res){
  var mod=new model(req.body); 
  console.log("inside mod",mod)
     mod.save(function(err,data){
         if(err)
         {
             res.send(err);
         }
         else{ 
           console.log("Data in add ")
             res.send({"success":true});
         }
     });
})

app.get('/viewdetails',function(req,res){
  console.log("inside view");
  model.find({},function(err,data){
      if(err)
      {
          res.send(err);
      }
      else{
          console.log("viewed")
          res.send(data);
      }
  });
})


// for view Table Data*************************************

app.get('/getAllDetails', function (request, response, next) {
  console.log("in  get js");
  fs.createReadStream('studentData.json').pipe(response);
})


// for store empDetails in empDB.json**********************
app.post('/send', (request, response) => {
  console.log(request.body);
  fs.readFile('./empDB.json', function (err, data) {
    var ArrayObject = JSON.parse(data);
    ArrayObject.push(request.body);
    console.log(ArrayObject);
    var empDetails = JSON.stringify(ArrayObject)
    if (fs.existsSync('./empDB.json')) {
      fs.writeFile('./empDB.json', empDetails, 'utf8', (err) => {
        if (err) {
          response.status(201).send({msg:"Failed by writing"});
        } else {
          response.status(200).send({msg:"success"});
        }
      })
    } else {
      response.status(201).send({msg:"Failed by file doesn't exsist"});
    }
  });
  // response.status(200).send({msg:"success"});
});

//add Student Details**************************************
app.post('/addStuDetails', (request, response) => {
  console.log(request.body);
  fs.readFile('./studentData.json', function (err, data) {
    var ArrayObject = JSON.parse(data);
    ArrayObject.push(request.body);
    console.log(ArrayObject);
    var empDetails = JSON.stringify(ArrayObject)
    if (fs.existsSync('./studentData.json')) {
      fs.writeFile('./studentData.json', empDetails, 'utf8', (err) => {
        if (err) {
          response.status(201).send({msg:"Failed by writing"});
        } else {
          response.status(200).send({msg:"success"});
        }
      })
    } else {
      response.status(201).send({msg:"Failed by file doesn't exsist"});
    }
  });
  // response.status(200).send({msg:"success"});
});


// filter data from cities.json**********************
app.post('/filter1', (request, response) => {
  console.log("filter",request.body.val);
  var substring = request.body.val;
  // fs.readFile('./cities.json', function (err, data) {
  //   var ArrayObject = JSON.parse(data);
  //   console.log(substring);
  //       if (err) {
  //         response.status(201).send({msg:"Failed by writing"});
  //       } else {
  //   var j=0;  var string1=[];
  //   for(var i=0;i<ArrayObject.length;i++){
  //     if(ArrayObject[i].city.includes(substring)){
  //      string1.push(ArrayObject[i])
  //     j++;
  //     }
  //   }
  //       response.status(200).send(string1);
  //       }
  // });
  fs.readFile('./citie.json', function (err, data) {
    var ArrayObject = JSON.parse(data);
    console.log(substring);
        if (err) {
          response.status(201).send({msg:"Failed by writing"});
        } else {
    var j=0;  var string1=[];
    for(var i=0;i<ArrayObject.length;i++){
      if(ArrayObject[i].includes(substring)){
       string1.push(ArrayObject[i])
      j++;
      }
    }
    console.log(string1);
        response.status(200).send(string1);
        }
  });
});



// identifier data ****************************************

app.post('/iden', (request, response) => {
  console.log("identifier",request.body.val);
  var substring = request.body.val;

  fs.readFile('./identifier.json', function (err, data) {
    var ArrayObject = JSON.parse(data);
    console.log(substring);
        if (err) {
          response.status(201).send({msg:"Failed by writing"});
        } else {
    var string1=[];
    for(var i=0;i<ArrayObject.length;i++){
      if(ArrayObject[i].includes(substring)){
        // var index=ArrayObject[i].indexOf(substring)
        var index=ArrayObject[i].indexOf(substring[substring.length-1])
        console.log(index,"***********")
        // if(index!=0){index=index+1}
        index=index+1
        string1.push(ArrayObject[i].slice(index))
      }
      else{
        string1.push(ArrayObject[i])
      }
    }
    console.log(string1);
        response.status(200).send(string1);
        }
  });
});

//*********************************************************
//Login
const JWT_Secret = 'your_secret_key'; 
app.post('/login', (req, res) => {
  var testUser = { userName: 'tamil', password: '123'};
  if (req.body) {
    var user = req.body;
    console.log(user)
    if (testUser.userName===req.body.userName && testUser.password === req.body.password) {
      var token = jwt.sign(user, JWT_Secret);
      res.status(200).send({
        signed_user: user,
        token: token,
        msg:"success"
      });
    } else {
      res.status(403).send({
        errorMessage: 'Authorisation required!'
      });
    }
  } else {
    res.status(403).send({
      errorMessage: 'Please provide email and password'
    });
  }
 
});
//*********************************************************

server.listen(port, hostName, () => {
  console.log("Page is hosted in " + port + ' in ' + hostName);
});