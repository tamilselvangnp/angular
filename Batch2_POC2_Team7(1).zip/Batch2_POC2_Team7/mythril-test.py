import os
import json
import sys

os.chdir(sys.argv[1])

with open('test-result.json') as f :
        result = json.load(f)

error_exceptionlist = ["Informational" , "Warning" ]
issues=result["result"]["issues"]

lis=[f for f in issues if f["type"] not in error_exceptionlist ]

print(lis)

print("Number of issues reported is ", len(lis))
if (len(lis)) != 0:
    sys.exit(1)
  
