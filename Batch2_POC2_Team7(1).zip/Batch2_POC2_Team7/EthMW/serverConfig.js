
// //P2PLending server configs

// let urlConfig = {   

//     middleware: {
//         dev: {
//             url: "http://localhost:8080/"
//         },
//         prod: {
//             url: "http://10.53.17.158:8080/"
//         }
//     },

//     blockchain: {
//         dev: {
//             url: "http://10.53.17.158:8017/"
//         },
//         prod: {
//             url: "http://10.53.17.158:8017/"
//         }
//       }
//   };

//   module.exports = urlConfig;