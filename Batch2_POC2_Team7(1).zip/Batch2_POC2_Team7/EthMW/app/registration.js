var express = require('express');
var router = express.Router();
var web3Config = require('./web3Config');
var fs = require('fs');

var database = './asset/database.json';


router.post('/registration' , function (request,response){

var name = request.body.name;
var partnerType = request.body.partner_type;
var password = request.body.password;

var length = 6;
var partnerId = parseInt(Math.random(length)*1000000);
console.log(partnerId);


let userDetails = {
    "partnerId": partnerId,
    "password": password,
    "partnerType": partnerType
}

// let web3=web3Config.web3;
let partnerContract = web3Config.PartnerContract();
//web3.personal.unlockAccount(web3.eth.accounts[0], web3.network.password); 
//{from:web3.eth.accounts[0],gas:4000000}
//web3Config.unlockAccount();
partnerContract.RegisterPartner(name,partnerId,partnerType,web3Config.getGasLimitPartner(),function(err,data){

    if(err){
        let JSONArray = {
            "msg": "fail"
        }
        console.log(err);
        response.status(500).send(err);

    }
    else{
        var txHash = data;
        while(web3Config.web3.eth.getTransactionReceipt(txHash)==null){
            console.log("Waiting for status...");
        }
        let status = web3Config.web3.eth.getTransactionReceipt(txHash).status;
        if(status == 0x1){
            let JSONArray = {
                "msg": "success",
                "partnerId":partnerId
            }
            fs.readFile(database, function (err, data) {
                var ArrayObject = JSON.parse(data);
                ArrayObject.push(userDetails);

                var ArrayString = JSON.stringify(ArrayObject)

                fs.writeFile(database, ArrayString, 'utf8', (err) => {
                    if (err) {
                        console.log(err);
                    }
                    else
                    {  
                        console.log("User details saved...");
                     }
                })
            })
            response.status(200).send(JSONArray);
            
        }else{
            let JSONArray = {
                "msg": "fail"
            }
            response.status(409).send(JSONArray);

        }

    }

})



});
module.exports = router;