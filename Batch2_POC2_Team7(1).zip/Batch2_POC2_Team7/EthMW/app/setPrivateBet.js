// for send invitation to partnerss


var express = require('express');
var router = express.Router();
var web3Config = require('./web3Config');





router.post('/setPrivateBet', function (request, response) {

    var bettingId = request.body.bettingId;


    var partnerIds = request.body.partnerId; // partner array


    let partnerContract = web3Config.PartnerContract();

    
    

    for (var i = 0; i < partnerIds.length; i++) {
        var flag = false;
        let partnetDetails = partnerContract.GetPartnerDetails.call(partnerIds[i]);
        var betList = partnetDetails[5];                    //invited bet list for partner i
        for(var j=0;j<betList.length;j++){
            if(betList[i] == bettingId){
                flag = true;
                break;
            }
        } 
      
        if (flag == false) {
            partnerContract.SetBettings(partnerIds[i], bettingId, web3Config.getGasLimitBettingMarket(),
                function (err, data) { })

        }
    }
    let JSONArray = {
        "msg": "success"
    }
    response.status(200).send(JSONArray);







});
module.exports = router;