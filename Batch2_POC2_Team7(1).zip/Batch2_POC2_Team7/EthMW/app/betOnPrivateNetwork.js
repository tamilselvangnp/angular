var express = require('express');
var router = express.Router();
var web3Config = require('./web3Config');


router.post('/betOnPrivateNetwork' , function (request,response){

    var partnerId = request.body.partnerId;
    var bettingId = request.body.bettingId; 
    var betAmount = request.body.betAmount;
    var odd       = request.body.odd;
    
    
    //let bettingContract = web3Config.BettingMarketContract();
    let partnerContract = web3Config.PartnerContract();


    
    partnerContract.AcceptBet(partnerId,bettingId,betAmount,odd,web3Config.getGasLimitPartner(),function(err,data){
    
        if(err){
            let JSONArray = {
                "msg": "fail"
            }
            response.status(500).send(JSONArray);
        }
        else{
            var txHash = data;
            while(web3Config.web3.eth.getTransactionReceipt(txHash)==null){
                console.log("Waiting for status...");
            }
        let status = web3Config.web3.eth.getTransactionReceipt(txHash).status;
        if(status == 0x1){
            let JSONArray = {
                "msg": "success"
            }
            response.status(200).send(JSONArray);
                
        }else{
            let JSONArray = {
                "msg": "lowBalance"
            }
            response.status(409).send(JSONArray);
    
            }
    
        }
    
    })
    
    
    });
    module.exports = router;