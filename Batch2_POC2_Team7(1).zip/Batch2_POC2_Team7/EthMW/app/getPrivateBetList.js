var express = require('express');
var router = express.Router();
var web3Config = require('./web3Config');


router.post('/getPrivateBetList' , function (request,response){

   
    
    let bettingContract = web3Config.BettingMarketContract();
    //let partnerContract = web3Config.PartnerContract();


    // let privateBetList = bettingContract.allPriveBetList.call();
    // arr = [];
    // for(var i = 0; i<privateBetList.length; i++){
    //     let privateBetdetails = bettingContract.GetPrivateBetDetailsById.call(privateBetList[i]);
    //     var betId = privateBetdetails[0];
    //     var bettingType = privateBetdetails[1];
    //     var bettingName =privateBetdetails[2];
    //     var partnerId = privateBetdetails[3];//array
    //     var odds = privateBetdetails[4];   //array
    //     var amount = privateBetdetails[5];
    //     let JSONObj = {
    //         "betId":parseInt(betId),
    //         "bettingType":bettingType,
    //         "bettingName":bettingName,
    //         "partnerId":partnerId,
    //         "odd": odds,
    //         "amount":parseInt(amount)
    //     }
    //     if(privateBetdetails[6]==true){
    //         arr.push(JSONObj);
    //     }
        


    // }







    let privateBetList = bettingContract.allPriveBetList.call();
    arr = []; temp = [];
    for(var i = 0; i<privateBetList.length; i++){
        betFlag = true;
        for (var j = 0; j < temp.length; j++) {
            if (betList[i] == temp[j]) {
                betFlag = false;
                break;
            }
        }
        if (betFlag==true) {

        let privateBetdetails = bettingContract.GetPrivateBetDetailsById.call(privateBetList[i]);
        var betId = privateBetdetails[0];
        var bettingType = privateBetdetails[1];
        var bettingName =privateBetdetails[2];
        var partnerId = privateBetdetails[3];//array
        var odds = privateBetdetails[4];   //array
        var amount = privateBetdetails[5];
        let JSONObj = {
            "betId":parseInt(betId),
            "bettingType":bettingType,
            "bettingName":bettingName,
            "partnerId":partnerId,
            "odd": odds,
            "amount":parseInt(amount)
        }
        if(privateBetdetails[6]==true){
            arr.push(JSONObj);
        }
    }
    }


    console.log("hi sumant",arr[0].odd);
    response.status(200).send(arr);

    
   
    
    });
    module.exports = router;