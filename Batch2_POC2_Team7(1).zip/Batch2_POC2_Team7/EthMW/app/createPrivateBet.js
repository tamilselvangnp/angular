var express = require('express');
var router = express.Router();
var web3Config = require('./web3Config');





router.post('/createPrivateBet' , function (request,response){

//var bettingId = request.body.bettingId;
// var bettingType = request.body.bettingType;
// var bettingName = request.body.bettingName;
// var partnerid = request.body.partnerId;
// var odds = request.body.odds;
// var betAmount = request.body.betAmount;
// var partnerIds = request.body.partnerId;
    var bettingType = request.body.Betting_type;
    var bettingName = request.body.betting_name;
    var partnerid = request.body.partner_id;
    var odds = request.body.odds;
    var betAmount = request.body.amount;
    var partnerIds = partnerid;
    console.log(partnerIds);

var length = 4;
var bettingId = parseInt(Math.random(length)*1000000);

console.log(bettingId)

let bettingContract = web3Config.BettingMarketContract();
let partnerContract = web3Config.PartnerContract();

bettingContract.CreatePrivateBet(bettingId,bettingType,bettingName,betAmount,partnerid,odds,web3Config.getGasLimitBettingMarket(),function(err,data){

    if(err){
        let JSONArray = {
            "msg": "fail"
        }
        response.status(500).send(JSONArray);

    }
    else{
        var txHash = data;
        while(web3Config.web3.eth.getTransactionReceipt(txHash)==null){
            console.log("Waiting for status...");
        }
        let status = web3Config.web3.eth.getTransactionReceipt(txHash).status;
        if(status == 0x1){
            let JSONArray = {
                "msg": "success"
            }
            response.status(200).send(JSONArray);
            
        }else{
            let JSONArray = {
                "msg": "fail"
            }
           response.status(409).send(JSONArray);

        }

    }

})

for (var i = 0; i < partnerIds.length; i++) {
    partnerContract.SetBettings(partnerIds[i], bettingId, web3Config.getGasLimitPartner(),
        function (err, data) { })

    
}

// let JSONArray = {
//                 "msg": "success"
//             }


// response.status(409).send(JSONArray);




});
module.exports = router;