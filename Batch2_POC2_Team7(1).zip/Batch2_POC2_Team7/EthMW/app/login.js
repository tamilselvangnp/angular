const express = require('express');
const http = require('http');
const fs = require('fs');
const app = express();
var router = express.Router();
const bodyParser = require('body-parser');
app.use(bodyParser.json());
var database = './asset/database.json';
const server = http.createServer(app);

router.post('/login', (request, response) => {
console.log("login");
console.log("this is body",request.body);
var flag = "false";
var fail={"msg":"fail"}
fs.readFile(database, function (err, data) {

    var ArrayObject = JSON.parse(data);
    console.log("array is", ArrayObject);

    for (var i = 0; i < ArrayObject.length; i++) {
        console.log(ArrayObject[i].partnerId);
        console.log(ArrayObject[i].password);


        if (ArrayObject[i].partnerId == request.body.partnerId && ArrayObject[i].password === request.body.password) {
            flag = "true";
            var result={
                "partnerId":ArrayObject[i].partnerId,
                "partnerType":ArrayObject[i].partnerType,
                "msg":"success"
            }
            response.status(200).send(result);

             console.log("success");
        }
    }
    if (flag === "false") {
        console.log("failed");
        response.send(fail);
        //response.status(400).send("failed");
    }


});

});

module.exports = router