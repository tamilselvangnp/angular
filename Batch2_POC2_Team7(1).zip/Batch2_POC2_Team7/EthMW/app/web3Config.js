var Web3 = require('web3');
var network = require("../asset/network.json")
var web3 = new Web3(new Web3.providers.HttpProvider(network.rpcurl));


//pcA 0xd3cda392be4b2aa989e9ee75ffbf451e333fbb70
//bcA 
var PartnerAddress = "0xd6b341b4ec9d6d59a4876de9ef6bec9d1e3d5c1c";
var BettingMarketAddress = "0xf0817f5481073de662c2491248b1a3ba75d1184f";

var PartnerABI = [{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"betDetails","outputs":[{"name":"BetID","type":"uint256"},{"name":"totalAmount","type":"uint256"},{"name":"status","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"users","outputs":[{"name":"Name","type":"string"},{"name":"PartnerID","type":"uint256"},{"name":"PartnerType","type":"string"},{"name":"wallet","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"GetAllActiveBets","outputs":[{"name":"","type":"uint256[]"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_PartnerID","type":"uint256"},{"name":"_BetID","type":"uint256"},{"name":"_BetAmount","type":"uint256"},{"name":"_odd","type":"uint256"}],"name":"AcceptBet","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_PartnerId","type":"uint256"}],"name":"GetPartnerDetails","outputs":[{"name":"","type":"string"},{"name":"","type":"uint256"},{"name":"","type":"string"},{"name":"","type":"uint256[]"},{"name":"","type":"uint256"},{"name":"","type":"uint256[]"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_BetID","type":"uint256"},{"name":"_PartnerID","type":"uint256"},{"name":"_WinnerCount","type":"uint256"},{"name":"_betingContractAddr","type":"address"}],"name":"winner","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_PartnerId","type":"uint256"},{"name":"_BetID","type":"uint256"}],"name":"SetBettings","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"GetAllUser","outputs":[{"name":"","type":"uint256[]"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_PartnerId","type":"uint256"},{"name":"_amount","type":"uint256"}],"name":"SetWalletBalance","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_Name","type":"string"},{"name":"_PartnerId","type":"uint256"},{"name":"_PartnerType","type":"string"}],"name":"RegisterPartner","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_BetID","type":"uint256"}],"name":"getAllBetDetails","outputs":[{"name":"","type":"uint256[]"},{"name":"","type":"uint256"},{"name":"","type":"uint256[]"},{"name":"","type":"uint256"},{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"}];
var BettingMarketABI = [{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"privateBet","outputs":[{"name":"BettingId","type":"uint256"},{"name":"BettingType","type":"string"},{"name":"BettingName","type":"string"},{"name":"BetAmount","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"betStatus","outputs":[{"name":"bettingId","type":"uint256"},{"name":"status","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_BettingId","type":"uint256"},{"name":"_BettingType","type":"string"},{"name":"_BettingName","type":"string"},{"name":"_BetAmount","type":"uint256"},{"name":"_odds","type":"uint256[]"}],"name":"CreatePublicBet","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_BettingId","type":"uint256"},{"name":"_BettingType","type":"string"},{"name":"_BettingName","type":"string"},{"name":"_BetAmount","type":"uint256"},{"name":"_PartnerID","type":"uint256[]"},{"name":"_odds","type":"uint256[]"}],"name":"CreatePrivateBet","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_BettingId","type":"uint256"}],"name":"setStatus","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"_BettingId","type":"uint256"}],"name":"GetPrivateBetDetailsById","outputs":[{"name":"","type":"uint256"},{"name":"","type":"string"},{"name":"","type":"string"},{"name":"","type":"uint256[]"},{"name":"","type":"uint256[]"},{"name":"","type":"uint256"},{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_BettingId","type":"uint256"}],"name":"GetPublicBetDetailsById","outputs":[{"name":"","type":"uint256"},{"name":"","type":"string"},{"name":"","type":"string"},{"name":"","type":"uint256[]"},{"name":"","type":"uint256"},{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"allPublicBetList","outputs":[{"name":"","type":"uint256[]"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[],"name":"allPriveBetList","outputs":[{"name":"","type":"uint256[]"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"publicBet","outputs":[{"name":"BettingId","type":"uint256"},{"name":"BettingType","type":"string"},{"name":"BettingName","type":"string"},{"name":"BetAmount","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"}];
var PartnerContract = function(){
    return web3.eth.contract(PartnerABI).at(PartnerAddress);
}
var BettingMarketContract = function(){
    return web3.eth.contract(BettingMarketABI).at(BettingMarketAddress);
}



var unlockAccount = function () {
    
    //console.log(web3.eth.accounts[0]);    
    web3.personal.unlockAccount(web3.eth.accounts[0], network.password);
}

var getGasLimitPartner = function () {
    PartnerContract();
    unlockAccount();
    return ({ from: web3.eth.accounts[0], gas: 0x2fefd88 });
}

var getGasLimitBettingMarket = function () {
    BettingMarketContract();
    unlockAccount();
    return ({ from: web3.eth.accounts[0], gas: 0x2fefd88 });
}


module.exports = {
    getGasLimitPartner : getGasLimitPartner,
    getGasLimitBettingMarket : getGasLimitBettingMarket,
    PartnerContract : PartnerContract, 
    BettingMarketContract : BettingMarketContract, 
    web3 :web3,
    unlockAccount:unlockAccount,
    BettingMarketAddress:BettingMarketAddress
    
}