var express = require('express');
var router = express.Router();
var web3Config = require('./web3Config');





router.post('/createPublicBets' , function (request,response){

//var bettingId = request.body.bettingId;
var bettingType = request.body.Betting_type;
var bettingName = request.body.betting_name;
var odds = request.body.odds;
var betAmount = request.body.amount;
var length = 4;
var bettingId = parseInt(Math.random(length)*1000000);




let bettingContract = web3Config.BettingMarketContract();

bettingContract.CreatePublicBet(bettingId,bettingType,bettingName,betAmount,odds,web3Config.getGasLimitBettingMarket(),function(err,data){

    if(err){
        let JSONArray = {
            "msg": "fail"
        }
        response.status(500).send(JSONArray);

    }
    else{
        var txHash = data;
        while(web3Config.web3.eth.getTransactionReceipt(txHash)==null){
            console.log("Waiting for status...");
        }
        let status = web3Config.web3.eth.getTransactionReceipt(txHash).status;
        if(status == 0x1){
            let JSONArray = {
                "msg": "success"
            }
            response.status(200).send(JSONArray);
            
        }else{
            let JSONArray = {
                "msg": "fail"
            }
            response.status(409).send(JSONArray);

        }

    }

})




});
module.exports = router;