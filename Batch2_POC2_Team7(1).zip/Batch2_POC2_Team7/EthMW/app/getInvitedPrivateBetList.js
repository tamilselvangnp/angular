var express = require('express');
var router = express.Router();
var web3Config = require('./web3Config');

router.post('/getInvitedPrivateBetList' , function (request,response){

    var partnerId = request.body.partnerId;
    // var bettingId = request.body.bettingId; 
    // var betAmount = request.body.betAmount;
    // var odd       = request.body.odd;
    

    let bettingContract = web3Config.BettingMarketContract();
    let partnerContract = web3Config.PartnerContract();

    let invitedBettings = partnerContract.GetPartnerDetails.call(partnerId);
    var invitedBetList = invitedBettings[5];
    console.log(invitedBetList);
    arr =[];
    for(var i=0;i<invitedBetList.length;i++){
        let betDetails = bettingContract.GetPrivateBetDetailsById.call(invitedBetList[i]);
        let JSONObj = {
            "bettingId":parseInt(betDetails[0]),
            "bettingType":betDetails[1],
            "bettingName":betDetails[2],
            "odds":betDetails[4],
            "betAmount":parseInt(betDetails[5])
        }
        if(betDetails[6]==true){
            arr.push(JSONObj);
        }
    }
    response.status(200).send(arr);
    
    
    });
    module.exports = router;