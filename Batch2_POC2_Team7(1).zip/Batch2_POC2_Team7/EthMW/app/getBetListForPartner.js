var express = require('express');
var router = express.Router();
var web3Config = require('./web3Config');


router.post('/getBetListForPartner' , function (request,response){

   
    
    let partnerContract = web3Config.PartnerContract();
    let bettingMarketContract = web3Config.BettingMarketContract();

    var partnerId = request.body.partnerId;
    arr = [];
    let partnerDetails = partnerContract.GetPartnerDetails.call(partnerId);
    var invitedBetList = partnerDetails[5];
    for(var i=0;i<invitedBetList.length;i++){
        let betDetails = bettingMarketContract.GetPrivateBetDetailsById.call(invitedBetList[i]);
        if(betDetails[6] == true){
            let JSONObj = {
                "bettingId":parseInt(betDetails[0]),
                "bettingName":betDetails[2],
                "bettingOdds":betDetails[4],
                "betAmount":parseInt(betDetails[5])
            }
            arr.push(JSONObj);
        }

    }
    response.status(200).send(arr);

    

    
   
    
    });
    module.exports = router;