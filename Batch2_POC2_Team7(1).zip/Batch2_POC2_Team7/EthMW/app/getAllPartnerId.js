const express = require('express');
const http = require('http');
const fs = require('fs');
const app = express();
var router = express.Router();
const bodyParser = require('body-parser');
app.use(bodyParser.json());
var database = './asset/database.json';
const server = http.createServer(app);

router.get('/getAllPartnerId', (request, response) => {


fs.readFile(database, function (err, data) {
var arr = [];
    var ArrayObject = JSON.parse(data);
    console.log("array is", ArrayObject);

    for (var i = 0; i < ArrayObject.length; i++) {
        if(ArrayObject[i].partnerType==="User"){
        let JSONObj = {
            "partnerId":ArrayObject[i].partnerId
        }
        arr.push(JSONObj);
        }
    }
       response.status(200).send(arr);


});

});

module.exports = router