var express = require('express');
var router = express.Router();
var web3Config = require('./web3Config');


router.post('/getPublicBetList' , function (request,response){

    
    
    let bettingContract = web3Config.BettingMarketContract();
    //let partnerContract = web3Config.PartnerContract();


    let publicBetList = bettingContract.allPublicBetList.call();
    arr = [];
    for(var i = 0; i<publicBetList.length; i++){
        let publicBetdetails = bettingContract.GetPublicBetDetailsById.call(publicBetList[i]);
        var betId = publicBetdetails[0];
        var bettingType = publicBetdetails[1];
        var bettingName =publicBetdetails[2];
        var odds = publicBetdetails[3];
        var amount = publicBetdetails[4];
        let JSONObj = {
            "betId":parseInt(betId),
            "bettingType":bettingType,
            "bettingName":bettingName,
            "odds": odds,   //array
            "amount":parseInt(amount)
        }

        if(publicBetdetails[5]==true){
            arr.push(JSONObj);
        }
       


    }
    response.status(200).send(arr);

    
   
    
    });
    module.exports = router;