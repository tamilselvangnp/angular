/* get lending data with lenders public key */

var express = require('express')
var router = express.Router();
var web3Config = require('./web3Config');

router.post('/getPartnerDetails', function (Request, response) {

var partnerId = Request.body.partnerId;
console.log(partnerId);

let partnerContract = web3Config.PartnerContract();

let details = partnerContract.GetPartnerDetails.call(partnerId)
console.log(details);

    let JSONArray = {
    "partnerName": details[0],
    "partnerId": details[1],
    "PartnerType": details[2],
    "addedBettings":details[3],
    "wallet":details[4]
}
console.log(JSONArray);
response.status(200).send(JSONArray);

});

module.exports = router