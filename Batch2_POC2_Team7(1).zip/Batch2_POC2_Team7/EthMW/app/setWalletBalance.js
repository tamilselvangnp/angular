var express = require('express');
var router = express.Router();
var web3Config = require('./web3Config');

router.post('/setWalletBalance' , function (request,response){

    var partnerId = request.body.partnerId;
    var amount    = request.body.add_amount;

    let partnerContract = web3Config.PartnerContract();

     partnerContract.SetWalletBalance(partnerId,amount,web3Config.getGasLimitPartner(),function(err,data){
    
       
    
    })

    let partnerDetails = partnerContract.GetPartnerDetails.call(partnerId);
    let JSONObj = {
        "msg":"success"
    }
    response.status(200).send(JSONObj);
    });
    module.exports = router;