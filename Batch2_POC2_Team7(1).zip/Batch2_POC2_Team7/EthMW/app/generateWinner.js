var express = require('express');
var router = express.Router();
var web3Config = require('./web3Config');

router.post('/generateWinner', function (request, response) {

    var betId = request.body.bettingId;
    let partnerContract = web3Config.PartnerContract();
    let bettingContract = web3Config.BettingMarketContract();


    let allBetDetails = partnerContract.getAllBetDetails.call(betId);
    var partnerArr = allBetDetails[0];
    var oddList = allBetDetails[2];

console.log( oddList[oddList.length - 1])

    var winningNumber = Math.floor(Math.random() * oddList[oddList.length - 1]) + 1;
console.log("winningNumber : ",winningNumber)



    var winners = [];
    var winningCount = 0;
    for (var i = 0; i < partnerArr.length; i++) {
        if (oddList[i] == winningNumber) {//check the partner id's which choose 
            //winningNember for particular betId
            winningCount++; //should have winners count
            winners.push(partnerArr[i]);// should push wiining partner id's
        }
    }
    console.log(winners);
    for (var i = 0; i < winningCount; i++) {
        partnerContract.winner(betId, winners[i], winningCount, web3Config.BettingMarketAddress,
            web3Config.getGasLimitPartner(), function (err, data) {
                if (err) {
                    let JSONArray = {
                        "msg": "fail"
                    }
                    response.status(500).send(JSONArray);
                }
                else {
                    var txHash = data;
                    while (web3Config.web3.eth.getTransactionReceipt(txHash) == null) {
                        console.log("Waiting for status...");
                    }
                    let status = web3Config.web3.eth.getTransactionReceipt(txHash).status;
                    if (status == 0x1) {
                        let JSONArray = {
                            "msg": "success"
                        }
                        response.status(200).send(JSONArray);

                    }else{
                        let JSONArray = {
                            "msg": "already generated"
                        }
                        response.status(200).send(JSONArray);
                    }

                }





            });


    }

    // let JSONArray = {
    //     "msg": "success"
    // }

    // response.status(200).send(JSONArray);











});
module.exports = router;