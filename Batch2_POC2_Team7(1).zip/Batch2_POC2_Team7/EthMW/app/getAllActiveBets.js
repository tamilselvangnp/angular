var express = require('express');
var router = express.Router();
var web3Config = require('./web3Config');
var f = require('./generateWinner');


router.post('/getAllActiveBets', function (request, response) {



    //let bettingContract = web3Config.BettingMarketContract();
    let partnerContract = web3Config.PartnerContract();


    // let betList = partnerContract.GetAllActiveBets.call();
    // arr = [];
    // for(var i = 0; i<betList.length; i++){
    //     let betdetails = partnerContract.getAllBetDetails.call(betList[i]);
    //     var partnerIds = betdetails[0];
    //     var betId = parseInt(betdetails[1]);
    //     var odds = betdetails[2];
    //     var totalAmount = parseInt(betdetails[3]);
    //     let JSONObj = {
    //        "partnerIds":partnerIds,
    //        "betId":betId,
    //        "odds":odds,
    //        "totalAmount":totalAmount
    //     }
    //     if(betdetails[4]==true && betId!=446621){
    //         arr.push(JSONObj);
    //     }

    // }  


    let betList = partnerContract.GetAllActiveBets.call();
    arr = [];
    temp = [];
    for (var i = 0; i < betList.length; i++) {
        betFlag = true;
        for (var j = 0; j < temp.length; j++) {
            if (betList[i] == temp[j]) {
                betFlag = false;
                break;
            }
        }
        if (betFlag==true) {
            let betdetails = partnerContract.getAllBetDetails.call(betList[i]);
            var partnerIds = betdetails[0];
            var betId = parseInt(betdetails[1]);
            var odds = betdetails[2];
            var totalAmount = parseInt(betdetails[3]);
            temp.push(betId);
            let JSONObj = {
                "partnerIds": partnerIds,
                "betId": betId,
                "odds": odds,
                "totalAmount": totalAmount
            }
            if (betdetails[4] == true && betId!=446621) {
                arr.push(JSONObj);
            }
        }
    }











        response.status(200).send(arr);




    });
module.exports = router;