/*
    index where all the features called and server initalized..
*/
var express = require('express');
var bodyParser = require('body-parser');
var cors = require('cors');

var betOnPrivateNetwork = require('./app/betOnPrivateNetwork');
var betOnPublicNetwork = require('./app/betOnPublicNetwork');
var createPrivateBet = require('./app/createPrivateBet');
var createPublicBets = require('./app/createPublicBets');
var generateWinner = require('./app/generateWinner');
var getAllActiveBets = require('./app/getAllActiveBets');
var getBetListForPartner = require('./app/getBetListForPartner');
var getInvitedPrivateBetList = require('./app/getInvitedPrivateBetList');
var getPartnerDetails = require('./app/getPartnerDetails');
var getPrivateBetList = require('./app/getPrivateBetList');
var getPublicBetList = require('./app/getPublicBetList');
var login = require('./app/login');
var registration = require('./app/registration');
var setWalletBalance = require('./app/setWalletBalance');
var getAllPartnerId = require('./app/getAllPartnerId');
 var web3Config = require('./app/web3Config'); 

var app = express();

app.use(cors());
app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json()); 

app.use('/api', betOnPrivateNetwork);
app.use('/api', betOnPublicNetwork);
app.use('/api', createPrivateBet);
app.use('/api', createPublicBets);
app.use('/api', generateWinner);
app.use('/api', getAllActiveBets);
app.use('/api', getBetListForPartner);
app.use('/api', getInvitedPrivateBetList);
app.use('/api', getPartnerDetails);
app.use('/api', getPrivateBetList);
app.use('/api', getPublicBetList);
app.use('/api', login);
app.use('/api', registration);
app.use('/api', setWalletBalance);
app.use('/api', getAllPartnerId);


app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

var server = app.listen(8080, (server) => console.log('Server Listening in port 8080'));

console.log(server.address());

