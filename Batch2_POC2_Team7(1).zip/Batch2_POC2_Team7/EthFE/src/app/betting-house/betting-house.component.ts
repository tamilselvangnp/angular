import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DataService } from '../data.service';

@Component({
  selector: 'app-betting-house',
  templateUrl: './betting-house.component.html',
  styleUrls: ['./betting-house.component.css']
})
export class BettingHouseComponent implements OnInit {

  Submit=false;
  accountDetailsForm:FormGroup;
  createPublicBetForm:FormGroup;
  betOnPublicNetworkForm:FormGroup;
  walletForm:FormGroup;
  partnerName;
  partnerId;
  PartnerType;
  wallets;
  accountDetails = false;
  createPublicBet = false;
  wallet = false;
  oddList;

  constructor(private betting:FormBuilder,public route:Router,public service:DataService) {
    if (this.service.crntpartnerId==undefined){
      alert("Please Login")
      this.logout();
    }

    this.createPublicBetForm = betting.group({
      Betting_type:['',([Validators.required])],
      betting_name:['', ([Validators.required])],
      amount: ['', ([Validators.required,Validators.pattern("[0-9']{1,43}$")])],
      odds: ['', ([Validators.required])],
    });
    this.walletForm = betting.group({
      add_amount: ['', ([Validators.required,Validators.pattern("[0-9']{1,43}$")])],
    });

  }

  addOdds() {
    this.oddList = ['1', '2', '3', '4', '5', '6']
  }

  ngOnInit() {
    this.AccountDetails();
  }

  logout(){
    this.service.crntpartnerId = undefined;
    // location.reload();
    this.route.navigate(['/home']);
    localStorage.clear();
  }

  get Validation1() {
    return this.accountDetailsForm.controls;
  };
  get Validation2(){
    return this.createPublicBetForm.controls;
  }
  get Validation3(){
    return this.betOnPublicNetworkForm.controls;
  }
  get Validation4(){
    return this.walletForm.controls;
  }

  //function to Get Account Details working e2e
  AccountDetails(){
    this.Submit=true;
    this.accountDetails = true;
    this.createPublicBet = false;
    this.wallet = false;
    this.Submit = true;
      var val = { 
        "partnerId":localStorage.getItem('partnerId')
      }
      console.log(val);
      this.service.AccountDetails1(val).subscribe(response => {
        console.log("create private bet", response)
        if (response) {
          this.partnerName =  response['partnerName'];
          this.partnerId = response['partnerId']
          this.PartnerType =    response['PartnerType']
          this.wallets = response['wallet']
          localStorage.setItem('partnerId', response['partnerId']);
          localStorage.setItem('name', response['partnerName']);
          localStorage.setItem('partnerType', response['PartnerType']);
          localStorage.setItem('wallets', response['wallet']);

          console.log(response);
          //this.route.navigate(['/homePage']);
        }
      })
     
    
  }

    // function for create public bet
  CreatePublicBet1(){
    this.Submit=true;
    if(this.createPublicBetForm.invalid){
      return;
    }
    else{
      //alert("waiting for status...");
      var val = this.createPublicBetForm.value;
      console.log(val);     
      this.service.CreatePublicBet1(val).subscribe(response => {
        console.log("create private bet", response)
        if (response) {
          //alert("success");
          console.log(response);
          //this.route.navigate(['/homePage']);
        }
      })
    }
  }

  // function for bet on public network
  BetOnPublicNetwork1(){
    this.Submit=true;
    if(this.betOnPublicNetworkForm.invalid){
      return;
    }
    else{
     // alert("success");
      var val = this.betOnPublicNetworkForm.value;
      console.log(val);     
      this.service.BetOnPublicNetwork1(val).subscribe(response => {
        console.log("create private bet", response)
        if (response) {
          console.log(response);
          //this.route.navigate(['/homePage']);
        }
      })
    }
  }

   // function for wallet working e2e
   Wallet1(){
    this.Submit=true;
    if(this.walletForm.invalid){
      return;
    }
    else{
      //alert("success");
      var val = {
        "partnerId":localStorage.getItem("partnerId"),
        "add_amount": this.walletForm.value.add_amount
      }
      console.log(val);     
      this.service.Wallet1(val).subscribe(response => {
        console.log("create private bet", response)
        if (response) {
          console.log(response);
          //alert("amount added");
          // this.accountDetails = true;
          // this.createPublicBet = false;
          // this.wallet = false;
         // this.route.navigate(['/betting-house']);
        }
      })
    }
  }

 

  CreatePublicBet() {
    this.accountDetails = false;
    this.createPublicBet = true;
    this.wallet = false;
  }

  Wallet() {
    this.accountDetails = false;
    this.createPublicBet = false;
    this.wallet = true;
  }
  
}