import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BettingHouseComponent } from './betting-house.component';

describe('BettingHouseComponent', () => {
  let component: BettingHouseComponent;
  let fixture: ComponentFixture<BettingHouseComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BettingHouseComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BettingHouseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
