import { Component, OnInit } from '@angular/core';
//import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../data.service';

import { Router } from '@angular/router';


@Component({
  selector: 'app-owner',
  templateUrl: './owner.component.html',
  styleUrls: ['./owner.component.css']
})
export class OwnerComponent implements OnInit {

  getAllBetList = false;
  allActiveBets;
  temp; count = 0; c; d; n;


  constructor(public service: DataService, public route: Router) {
    
    if (this.service.crntpartnerId == undefined) {
      alert("Please Login")
      this.logout();
    }
  }

  ngOnInit() {
  }

  logout() {
   // location.reload();
   this.service.crntpartnerId = undefined;
    this.route.navigate(['/home']);
    localStorage.clear();
  }

  GetAllBetList1() {
    this.getAllBetList = true;
    this.service.GetAllBetList1().subscribe(response => {
      console.log("get all active bet list", response)
      if (response) {
       this.allActiveBets=response;
        console.log(this.allActiveBets);
        //this.route.navigate(['/homePage']);
      }
    })



    //int n-length of Response, allActiveBets-result, temp-response, count = 0, c, d;
    // this.getAllBetList = true;
    // this.service.GetAllBetList1().subscribe(response => {
    //   console.log("get all active bet list", response)
    //   this.temp = response;
    //   this.n = this.temp.length;
    //   for (this.c = 0; this.c < this.n; this.c++) {
    //     for (this.d = 0; this.d < this.count; this.d++) {
    //       if (this.temp[this.c] == this.allActiveBets[this.d])
    //         break;
    //     }
    //     if (this.d == this.count) {
    //       this.allActiveBets[this.count] = this.temp[this.c];
    //       this.count++;
    //     }
    //   }
    //   console.log("edited bet list",this.allActiveBets);
    // })



  }

  GenerateWinner(BetId) {
    //alert("abhishek");
    var val = {
      "bettingId": BetId
    }

    this.service.GenerateWinner1(val).subscribe(response => {
      console.log("Generate winner ", response)
      if (response) {
        console.log(response);
        //this.route.navigate(['/homePage']);
      }
    })
  }

  Wallet() {
    this.getAllBetList = true;
  }
}
