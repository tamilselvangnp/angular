import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../data.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  regSubmit = false;

  constructor(public route: Router, public login: FormBuilder, private service: DataService) {
    this.loginForm = login.group({
      partnerId: ['', ([Validators.required, Validators.pattern("[0-9']{1,43}$")])],
      password: ['', ([Validators.required, Validators.pattern("^(?=.*?[A-Z])(?=.*?[a-z])(?!.* )(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")])]
    })
  }
  Register() {
    this.route.navigate(['registration']);
  }
  ngOnInit() {
  }

  get loginValidation() {
    return this.loginForm.controls
  };

  loginFormSubmit() {
    this.regSubmit = true;
    if (this.loginForm.invalid) {
      alert("fill all details carefully ")
      return;
    } else {

      
      var val = this.loginForm.value;
      console.log(val);
      // this.route.navigate(['/homePage']);
      this.service.loginFormSubmit(val).subscribe(response => {
        console.log("LoginForm", response['partner_type']);
        // for user type
        if (response['msg'] == "success" && response['partnerType'] == "User") {
          //alert("Success Login.");
          this.service.crntpartnerId=response['partnerId'];
          console.log(response);
          localStorage.setItem("partnerId", response['partnerId']);          
          this.route.navigate(['/user']);
        }
        //for betting house type
        else if (response['msg'] == "success" && response['partnerType'] == "Betting_House") {
         // alert("Success Login.");
          this.service.crntpartnerId=response['partnerId'];
          localStorage.setItem("partnerId", response['partnerId']);
          this.route.navigate(['/betting-house']);
          console.log(response['partnerType']);
        }
        // for owner type
        else if (response['msg'] == "success" && response['partnerType'] == "Owner") {
          //alert("Success Login.");
          this.service.crntpartnerId=response['partnerId'];
          localStorage.setItem("partnerId", response['partnerId']);
          this.route.navigate(['/owner']);
        }
        //invalid credentails
        else if (response == '') {
          alert("Invalid Credentials.");
        }else{alert("Invalid Credentials.")}
      });
      this.loginForm.reset();
    }
  }
}