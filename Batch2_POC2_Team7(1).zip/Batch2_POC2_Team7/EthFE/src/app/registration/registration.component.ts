import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../data.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  registrationForm: FormGroup;
  regSubmit = false;

  constructor(public route: Router, public registration: FormBuilder, private service: DataService) {

    this.registrationForm = registration.group({
      name: ['', ([Validators.required, Validators.pattern("[a-zA-Z ']{1,15}$")])],
      //password: ['', ([Validators.required])],
      password: ['', ([Validators.required, Validators.pattern("^(?=.*?[A-Z])(?=.*?[a-z])(?!.* )(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$")])],
      partner_type: ['', ([Validators.required])]
    });
  }
  ngOnInit() {
  }
  
  Login(){
    this.route.navigate(['/home']);
  }

  get regValidation() {
    return this.registrationForm.controls
  };

  registrationFormSubmit() {
    this.regSubmit = true;
    if (this.registrationForm.invalid) {
      alert("invalid password");
      return;
    } else {
      alert("wait for partnerID");
      var val = this.registrationForm.value;
      console.log(val);
      //this.route.navigate(['/home']);
      this.service.registrationFormSubmit(val).subscribe(response => {
        console.log("Registration", response)
        if (response) {
          console.log(response);
          alert("PartnerId is : "+response['partnerId']);
          localStorage.setItem('partnerId', response['partnerId']);
          this.route.navigate(['/home']);
        }
      });
      this.registrationForm.reset();
    }
  }
}