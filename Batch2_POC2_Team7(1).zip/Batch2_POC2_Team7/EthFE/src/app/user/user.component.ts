import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DataService } from '../data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  //partnerList:any;
  partnerList=[];
  oddList: string[] = [];
  Submit = false;
  accountDetailsForm: FormGroup;
  walletForm: FormGroup;
  createPrivateBetForm: FormGroup;
  betOnPublicNetworkForm: FormGroup;
  getPrivateBetForm: FormGroup;
  betOnPrivateNetworkForm: FormGroup;
  getPublicBetListForm: FormGroup;
  partnerId = '';
  partnerName = '';
  addedBettings = '';
  wallets = '';
  PartnerType = '';
  odds = '';
  allBets1;
  allBets2;
  walletBalance;
  allodd;
  allodd2;
  check;v;
  check1;v1;
  usr = '';
  checker(v){
    this.check=v;
  }
  checker1(v1){
    this.check1=v1;
  }

  accountDetails = true;
  createPrivateBet = false;
  getPrivateBet = false;
  getPublicBetList = false;
  wallet = false;

  // constructor(public user: FormBuilder, public service: DataService, public route: Router) {

  //   this.createPrivateBetForm = user.group({
  //     Betting_type:['',([Validators.required])],
  //     betting_name: ['', ([Validators.required])],
  //     partner_id: ['', ([Validators.required])],
  //     amount: ['', ([Validators.required])],
  //     odds: ['', ([Validators.required])]
  //   });


  constructor(public user: FormBuilder, public service: DataService, public route: Router) {
 if (this.service.crntpartnerId==undefined){
   alert("Please Login")
   this.logout();
 }

 this.usr = localStorage.getItem('name');
    this.createPrivateBetForm = user.group({
      Betting_type:['',([Validators.required])],
      betting_name:['', ([Validators.required])],
      
      partner_id: ['', ([Validators.required])],
      amount: ['', ([Validators.required,Validators.pattern("[0-9']{1,43}$")])],
      odds: ['', ([Validators.required])],
    });


    this.walletForm = user.group({
      add_amount: ['', ([Validators.required,Validators.pattern("[0-9']{1,43}$")])],
    });

  }



  

  ngOnInit() {
    this.AccountDetails();
   // this.spinner.show();
  }

  // for(this.i=0;i<6;i++){
    
  // }

  get Validation1() {
    return this.createPrivateBetForm.controls;
  };
  get Validation2() {
    return this.getPrivateBetForm.controls;
  }
  get Validation3() {
    return this.betOnPrivateNetworkForm.controls;
  }
  get Validation4() {
    return this.getPublicBetListForm.controls;
  }
  get Validation5() {
    return this.walletForm.controls;
  }
  get Validation6() { 
    return this.accountDetailsForm.controls;
  };

t;
 
  Invite() {
    //this.partnerList = ['254429','447153','878615','831818','115505','18031','564528'];
     this.service.allUserIds().subscribe(response => {
     console.log("All Ids", response);
     this.t=response;
     for(var i = 0; i< this.t.length; i++)
      {
        //console.log("id's",this.t[i].partnerId);
        this.partnerList[i]=this.t[i].partnerId;
        //console.log("id's in pL",this.partnerList[i]);
    }
     })
    
    
  }
  logout(){
    this.service.crntpartnerId = undefined;
    //location.reload();
    this.route.navigate(['/home']);
    localStorage.clear();
  }

  addOdds() {
    this.oddList = ['1', '2', '3', '4', '5', '6']
  }
  

  //function to Get Account Details
  // AccountDetails1() { 
  //   this.Submit = true;
  //     this.partnerId = localStorage.getItem('partnerId');
  //     var val = {"partnerId": this.partnerId}
  //     console.log(val); 
  //     console.log(this.partnerId);
  //     this.service.AccountDetails1(val).subscribe(response => {
  //       console.log("create private bet", response)
  //       if (response) {
  //         this.partnerName =  response['partnerName'];
  //         this.partnerId = response['partnerId']
  //         this.PartnerType =    response['PartnerType']
  //         this.addedBettings = response['addedBettings']
  //         this.wallets = response['wallets']
         

  //         localStorage.setItem('partnerId', response['partnerId']);
  //         localStorage.setItem('name', response['partnerName']);
  //         localStorage.setItem('partnerType', response['PartnerType']);
  //         localStorage.setItem('addedBetting', response['addedBettings']);
  //         localStorage.setItem('wallets', response['wallets']);

  //         console.log(response);
  //         //this.route.navigate(['/homePage']);
  //       }
  //     })
    
  // }


  // function for Create Private bet is working e2e
  CreatePrivateBet1() {
    this.Submit = true;
    console.log("creating");
    if (this.createPrivateBetForm.invalid) {  
      console.log("error");
      return;
    }
    else {  
      console.log("pass");     
      var val = this.createPrivateBetForm.value;
      console.log(val);
      this.service.CreatePrivateBet1(val).subscribe(response => {
        console.log("create private bet", response)
        if (response) {
          console.log(response);
          alert("Bet Created");
          this.odds = response['odd'];
          //this.route.navigate(['/homePage']);
        }
      })
    }
  }

  // function for Get Private bet
  GetPrivateBet1() {
    this.accountDetails = false;
    this.createPrivateBet = false;
    this.getPrivateBet = true;
    this.getPublicBetList = false;
    this.wallet = false;
    this.Submit = true;
    //alert("searching...");
    
      this.service.GetPrivateBet1().subscribe(response => {
        if (response) {
          this.allBets1 = response;
          console.log("all bets list",this.allBets1);
          console.log("odds",this.allBets1[0].odd);
          this.allodd = this.allBets1[0].odd;
        }
      })
    
  }

  // function for Bet on private network workinng e2e
  BetOnPrivateNetwork1(betId, odd, amount) {
    this.Submit = true;
    
      var val = {
        "partnerId": localStorage.getItem("partnerId"),
        "bettingId": betId,
        "betAmount": amount,
        "odd": this.check
      }
      //alert("wait for acceptance")
      console.log("accepetd odd value",val);
      this.service.BetOnPrivateNetwork1(val).subscribe(response => {
        if (response) {
          this.allBets1 = response;
          
          alert("accepted");
        }
        else if(response[0].msg=="lowBalance"){
          //alert("low balance");
        }
        else {
         // alert("error");
        }
      })
    
  }


  // function for get public bet list working e2e
  GetPublicBetList() {
    this.accountDetails = false;
    this.createPrivateBet = false;
    this.getPrivateBet = false;
    this.getPublicBetList = true;
    this.wallet = false;
    this.Submit = true;
    //alert("searching...");
      this.service.GetPublicBetList1().subscribe(response => {
        console.log("get public bet details", response)
        if (response) {
          this.allBets2 = response;
          console.log("all bets list",this.allBets2);
          console.log("odds",this.allBets2[0].odds);
          this.allodd2 = this.allBets2[0].odds;          
        }
      })
    
  }

  // function for bet on public network ned to be checked
  BetOnPublicNetwork1(betId, Odds, amount) {
    this.Submit = true;

    var val = {
      "partnerId": localStorage.getItem("partnerId"),
      "bettingId": betId,
      "betAmount": amount,
      "odd": this.check1 //single value
    }
    console.log(val)

    this.service.BetOnPublicNetwork1(val).subscribe(response => {
      
      if (response) {
       // this.allBets2 = response;
        //alert("wait of winning declaration");
      }
      else {
       // alert("Error");
      }
    })
  }

  // add amount to wallet working e2e
  Wallet1() {
    this.Submit = true;

    //console.log(this.walletForm.invalid);
    if (this.walletForm.invalid) {
      //alert("fail");
      return;
    }
    else {
     // alert("wait for success");
      var val={
        "partnerId":localStorage.getItem('partnerId'),
        "add_amount": this.walletForm.value.add_amount
      }
      console.log(val);
      
      this.service.Wallet1(val).subscribe(response => {
        console.log("create private bet", response)
        if (response) {
          console.log(response);
          //set wallet balance
          this.walletBalance = response;
          //this.route.navigate(['/homePage']);
          alert("amount added")
        }
      })
    }
  }


  //account details working e2e
  AccountDetails() {
    this.accountDetails = true;
    this.createPrivateBet = false;
    this.getPrivateBet = false;
    this.getPublicBetList = false;
    this.wallet = false;
    var val={
      "partnerId":localStorage.getItem('partnerId')
    }
    console.log("this is user partner id",val);
    this.service.AccountDetails1(val).subscribe(response => {
      console.log("User details", response)
      if (response) {
        this.partnerName =  response['partnerName'];
        this.partnerId = response['partnerId']
        this.PartnerType =    response['PartnerType']
        this.addedBettings = response['addedBettings']
        this.wallets = response['wallet']      

        localStorage.setItem('partnerId', response['partnerId']);
        localStorage.setItem('name',response['partnerName'] );
        localStorage.setItem('partnerType', response['PartnerType']);
        localStorage.setItem('addedBetting', response['addedBettings']);
        localStorage.setItem('wallets', response['wallet']);

        console.log(response);
        //this.route.navigate(['/homePage']);
      }
    })



  }

  CreatePrivateBet() {
    this.accountDetails = false;
    this.createPrivateBet = true;
    this.getPrivateBet = false;
    this.getPublicBetList = false;
    this.wallet = false;
  }
  // GetPrivateBet() {
  //   this.accountDetails = false;
  //   this.createPrivateBet = false;
  //   this.getPrivateBet = true;
  //   this.getPublicBetList = false;
  //   this.wallet = false;
  // }

  Wallet() {
    this.accountDetails = false;
    this.createPrivateBet = false;
    this.getPrivateBet = false;
    this.getPublicBetList = false;
    this.wallet = true;
  }

}