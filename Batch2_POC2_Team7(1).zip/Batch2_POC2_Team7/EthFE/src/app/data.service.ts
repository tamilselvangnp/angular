import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  crntpartnerId= undefined;

  constructor(private http: HttpClient) { }

  // service for registration
  registrationFormSubmit(userData) {
    console.log("users data", userData);
    return this.http.post('http://localhost:8080/api/registration', userData, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    });
  }

  // service for account details
  AccountDetails1(userData) {
    console.log("users data", userData);
    return this.http.post('http://localhost:8080/api/getPartnerDetails', userData, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    });
  }

  //service for login
  loginFormSubmit(loginData) {
    console.log("login data", loginData);
    return this.http.post('http://localhost:8080/api/login', loginData, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    });
  }

  //service for createPrivateBet1
  CreatePrivateBet1(createPrivateBetData) {
    console.log("create private bet", createPrivateBetData);
    return this.http.post('http://localhost:8080/api/createPrivateBet', createPrivateBetData, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    });
  }

  //service for getPrivateBet1
  GetPrivateBet1() {
    console.log("get private bet" );
    return this.http.post('http://localhost:8080/api/getPrivateBetList',  { 
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    });
  }

  //service for betOnPrivateNetwork1
  BetOnPrivateNetwork1(betOnPrivateNetworkData) {
    console.log("bet on private network", betOnPrivateNetworkData);
    return this.http.post('http://localhost:8080/api/betOnPrivateNetwork', betOnPrivateNetworkData, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    });
  }

  //service for createPublicBet1
  CreatePublicBet1(createPublicBetData) {
    console.log("create public bet", createPublicBetData);
    return this.http.post('http://localhost:8080/api/createPublicBets', createPublicBetData, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json', 
      })
    });
  }

  //service for getPublicBetList1
  GetPublicBetList1() {
    console.log("get public bet list");
    return this.http.post('http://localhost:8080/api/getPublicBetList', {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    });
  }

  //service for betOnPublicNetwork1
  BetOnPublicNetwork1(betOnPublicNetworkData) {
    console.log("bet on public network", betOnPublicNetworkData);
    return this.http.post('http://localhost:8080/api/betOnPublicNetwork', betOnPublicNetworkData, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    });
  }

  //service for GetBetList1
  GetAllBetList1() {
    console.log("get all bet list");
    return this.http.post('http://localhost:8080/api/getAllActiveBets', {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    });
  }

  //service for GenerateWinner1
  GenerateWinner1(generateWinnerData) {
    console.log("generate winner", generateWinnerData);
    return this.http.post('http://localhost:8080/api/generateWinner', generateWinnerData, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    });
  }

    //get all registered user
    allUserIds() {
      console.log("generate winner");
      return this.http.get('http://localhost:8080/api/getAllPartnerId', {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
        })
      });
    }

  //service for Wallet1
  Wallet1(walletData) {
    console.log("wallet", walletData);
    return this.http.post('http://localhost:8080/api/setWalletBalance', walletData, {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      })
    });
  }
}