var express = require("express");
var app = express();
var cors = require('cors');
var fs = require('fs');
var port = 8080;
// Add headers
app.use(function (req, res, next) {

  // Website you wish to allow to connect
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:8080/registration');
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:8080/*');
  res.setHeader('Access-Control-Allow-Origin', '*');

  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:8080/login');
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:8080/profileCreate');
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:8080/getJob');
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:8080/getEmployee');
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:8080/editJobDetails');
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:8080/editEmployeeDetails');
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:8080/searchCandidatesByCompetency');

  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:8080/getAllJobs');
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:8080/getAllEmployees');
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:8080/getAppliedJobs');
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:8080/searchApplicantsByJobId');
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:8080/getJobs');
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:8080/getUserDetails');

  // Request methods you wish to allow
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

  // Request headers you wish to allow
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

  // Set to true if you need the website to include cookies in the requests sent
  // to the API (e.g. in case you use sessions)
  res.setHeader('Access-Control-Allow-Credentials', true);

  // Pass to next layer of middleware
  next();
});


var bodyParser = require("body-parser");
app.use(bodyParser.json({ limit: "50mb" }));
app.use(bodyParser.urlencoded({ limit: "50mb", extended: true, parameterLimit: 50000 }));
app.use(cors())

console.log("i am working");

app.listen(port, () => console.log("Express server is runnong on port : " + port));


// Registration Api
app.post("/registration", function (req, res) {
  var Name = req.body.name;
  //var Last_Name = req.body.lastName;
  //var email = req.body.email;
  var Pass_word = req.body.password;
  var partner_Type = req.body.partner_type;
  //var details = req.body;
  console.log(Name);
  //console.log(Last_Name);
  //console.log(email);
  console.log(Pass_word);
  console.log(partner_Type);
  console.log("user registered");
  fs.readFile('credentials.json', 'utf8', function readFileCallback(err, data) {
    if (err) {
      console.log(err, "sumant");
    } else {
      obj = JSON.parse(data);
      obj.push(details);
      json = JSON.stringify(obj);
      fs.writeFileSync('credentials.json', json, 'utf8');
      
      res.status(200).send({ "success": true });
      res.end("record added");
    }
  });
});


// Login Api 
app.post("/login", function (req, res) {
  var email = req.body.partnerId;
  var Pass_word = req.body.password;
  console.log(partnerId);
  console.log(Pass_word);
  var obj = fs.readFileSync('credentials.json');
  var jsonObj = JSON.parse(obj);
  for (var i = 0; i < jsonObj.length; i++) {
    console.log("hi sumant i am in loop");
    if (jsonObj[i].partnerId == partnerId && jsonObj[i].password == Pass_word) {
      //console.log(jsonObj[i].email,"id nd pw",jsonObj[i].password);
      if (jsonObj[i].partner_Type === "User") {
        console.log("login success");
        console.log(name)
        console.log("hi sumant i am employeer");
        res.status(200).send({ "success": true, "userType": "employeer", "empId": empId, "userName": name,"email": email,"password": password  });
      } else if (jsonObj[i].partner_Type === "Betting_House") {
        console.log("login success");
        console.log("hi sumant i am employee");
        console.log(jsonObj[i].partner_Type);
        res.end("login ssss");
      } else {
        console.log("Invalid Id or Pw.");
        res.end("login successfull");
      }
    }
  }
});
module.exports = app;