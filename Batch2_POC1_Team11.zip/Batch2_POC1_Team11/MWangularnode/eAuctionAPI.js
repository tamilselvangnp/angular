var express = require('express');
var Web3 = require('web3');
var app = express();
const http = require('http');
var web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8405"));
var bodyParser = require('body-parser');
var cors = require('cors');
app.use(cors());
//app.use(bodyParser.urlencoded());
app.use(bodyParser.json());
// const server = http.createServer(app);
app.use(function (req, res, next) {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader(
        "Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, PATCH, DELETE");
    res.setHeader(
        "Access-Control-Allow-Headers", "X-Requested-With,content-type");
    res.setHeader("Access-Control-Allow-Credentials", true);
    next();
});

var contractAdd = "0xef39ee3148b9aa5e7c1824e9e9d1008f43710d21";
var abi =[{"constant":true,"inputs":[{"name":"userName","type":"uint8"},{"name":"password","type":"uint256"}],"name":"login","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"productID","type":"uint8"}],"name":"getTopBid","outputs":[{"name":"userName","type":"uint256"},{"name":"bidamount","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"userPassword","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"userName","type":"uint8"}],"name":"getDetailsByUserName","outputs":[{"name":"","type":"bytes32"},{"name":"","type":"bytes32"},{"name":"","type":"bytes32"},{"name":"","type":"uint256"},{"name":"","type":"uint256"},{"name":"","type":"bytes32"},{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"productID","type":"uint8"},{"name":"productName","type":"bytes32"},{"name":"manufacturerAddress","type":"bytes32"},{"name":"productDescription","type":"bytes32"},{"name":"date","type":"uint256"},{"name":"startTime","type":"uint256"},{"name":"endTime","type":"uint256"},{"name":"kickOffAmount","type":"uint256"}],"name":"addProductDetail","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"AllBids","outputs":[{"name":"userName","type":"uint256"},{"name":"bidAmount","type":"uint256"},{"name":"productID","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"","type":"uint256"}],"name":"userAccounts","outputs":[{"name":"","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"productID","type":"uint8"}],"name":"getProductById","outputs":[{"name":"productID1","type":"uint256"},{"name":"productName","type":"bytes32"},{"name":"manufacturerAddress","type":"bytes32"},{"name":"productDescription","type":"bytes32"},{"name":"date","type":"uint256"},{"name":"startTime","type":"uint256"},{"name":"endTime","type":"uint256"},{"name":"kickOffAmount","type":"uint256"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"userName","type":"uint8"},{"name":"firstName","type":"bytes32"},{"name":"lastName","type":"bytes32"},{"name":"contactAddress","type":"bytes32"},{"name":"phoneNumber","type":"uint256"},{"name":"email","type":"bytes32"},{"name":"password","type":"uint256"},{"name":"wallet","type":"uint256"}],"name":"Setuser","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"bidAmount","type":"uint256"},{"name":"userName","type":"uint8"},{"name":"productID","type":"uint256"}],"name":"submitBid","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":true,"inputs":[],"name":"getAllUsers","outputs":[{"name":"","type":"uint256[]"},{"name":"","type":"uint256[]"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"buyerId","type":"uint8"},{"name":"bidAmount","type":"uint256"},{"name":"sellerId","type":"uint8"}],"name":"sendDeposit","outputs":[{"name":"","type":"bool"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"inputs":[],"payable":false,"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":false,"name":"","type":"string"}],"name":"AlertsendDeposit","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"","type":"string"},{"indexed":false,"name":"","type":"uint256"}],"name":"alert","type":"event"}];

var contractOBJ = web3.eth.contract(abi).at(contractAdd);
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
/*app.all('/',function(req,res){
console.log(verification);
var x=web3.personal.unlockAccount(web3.eth.accounts[0],123);
console.log(x);
});*/

// function unlockAccount() {
// web3.personal.unlockAccount(web3.eth.accounts[0], 1234)
// return web3.eth.accounts[0];
// }

app.post('/Setuser', function (req, res) {

    var userName = req.body.userName;
    var firstName = req.body.firstName;
    var lastName = req.body.lastName;
    var contactAddress = req.body.contactAddress;
    var phoneNumber = req.body.phoneNumber;
    var email = req.body.email;
    var password = req.body.password;
    var wallet = req.body.wallet;
    console.log("userName",userName);
    console.log("firstName",firstName);
    console.log("lastName",lastName);
    console.log("contactAddress",contactAddress);
    console.log("phoneNumber",phoneNumber);
    console.log("email",email);
    console.log("password",password);
    console.log("wallet",wallet);
    //console.log("hii");

    web3.personal.unlockAccount(web3.eth.accounts[0],"1234")
    var gasValue;
    // contractOBJ.Setuser.estimateGas(userName,firstName,lastName,contactAddress,phoneNumber,email,password, wallet, { from: web3.eth.accounts[0] }, function (err, value) {
    //         if (err) {
    //             console.log("Err : ", err)
    //         }
    //         else {
    //             gasValue = value;
    //             console.log("Gas Value... : ", gasValue)
    //         }
    //     })
        contractOBJ.Setuser(userName, firstName,lastName,contactAddress,phoneNumber,email,password,wallet, { from: web3.eth.accounts[0], gas: 300000 }, function (err, value) {

            let txHash;
            if (err) {
                console.log(err)
            } else {
                //txHash 
                txHash = value;
                console.log("txHash"+value);
                while (web3.eth.getTransactionReceipt(txHash)== null) {
                    console.log("mining");
                }
                console.log("mining completed....");
                let status = web3.eth.getTransactionReceipt(txHash).status;
                console.log("status = "+status);
                if (status == 0x1) {
                    console.log("true");

                    res.send("true");

                }
                else if (status == 0x0) {
                    console.log("user already register");
                    res.send("false");
                }
                //res.send(value);
            }

        })
})


app.post('/getDetailsByUserName', function (req, res) {
    web3.personal.unlockAccount(web3.eth.accounts[0], "1234");
    var userName = req.body.userName;
    console.log(userName);
    //var details = [];
    //console.log(getDetailsByUserName);
    var value = contractOBJ.getDetailsByUserName.call(userName);
    //console.log(value[0]);
    //var resUsername = value[0];
    //var resFirstnamee = value[1];
     let JSONArray = {
        // "userName": parseInt(value[0]),
         "firstName": web3.toUtf8(value[0]),
         "lastName": web3.toUtf8(value[1]),
        "contactAddress": web3.toUtf8(value[2]),
         "phoneNumber": parseInt(value[4]),
        "email": web3.toUtf8(value[5]),
         "wallet": parseInt(value[6])

     }
    
    //details.push(n);
    console.log(JSON.stringify(JSONArray));
    res.send(JSON.stringify(JSONArray));
});

app.post("/login", function (req, res) {
    web3.personal.unlockAccount(web3.eth.accounts[0], "1234");
    var userName = req.body.userName;
    var password = req.body.password;
    //console.log("pubKey"+pubKey);
    let allUserDetails = contractOBJ.getAllUsers.call();
    let arr1 = allUserDetails[0];
    let arr2 = allUserDetails[1];
    //console.log("allUserDetails"+allUserDetails);
    for (var i = 0; i < arr1.length; i++) {
        //console.log("user[", i, "]" + allUserDetails[i]);
        if (arr1[i] == userName && arr2[i] == password) {
            console.log("true");
            res.send("true");
        }
        else{
            console.log("false");
            res.send("false"); 
        }
    }
});

// app.post('/login', async function (req, res) {
// //var value = contract.login.call(userName, password, { from: unlockAccount() });
// console.log(value);
// res.send(value);
// })

app.post('/addProductDetail', function (req, res) {                   //Registration

    var productID = req.body.productID;
    var productName = req.body.productName;
    var manufacturerAddress = req.body.manufacturerAddress;
    var kickOffAmount = req.body.kickOffAmount;
    var productDescription = req.body.productDescription;
    var date = req.body.date;
    var startTime = req.body.startTime;
    var endTime = req.body.endTime;

    //console.log("hii");
    web3.personal.unlockAccount(web3.eth.accounts[0], "1234");
    let gasValue;
    contractOBJ.addProductDetail.estimateGas(productID, productName, manufacturerAddress,
        productDescription, kickOffAmount, date, startTime, endTime, { from: web3.eth.accounts[0] }, function (err, value) {
            if (err) {
                console.log("Err : ", err)
            }
            else {
                gasValue = value;
                console.log("Gas Value... : ", value)
            }

            contractOBJ.addProductDetail(productID, productName, manufacturerAddress,
                productDescription, kickOffAmount, date, startTime, endTime, { from: web3.eth.accounts[0], gas: gasValue }, function (err, value, data)
                //var hash= await contract.createBuyerProfile(buyerID,name,email,location,accountBalance,{from:unlockAccount(),gas:contract.setDetails.estimateGas("name")},function(err,value)
                {
                    let txHash;
            if (err) {
                console.log(err)
            } else {
                //txHash 
                txHash = value;
                console.log(value);
                while (web3.eth.getTransactionReceipt(txHash) == null) {
                    console.log("mining");
                }
                console.log("mining completed....")
                let status = web3.eth.getTransactionReceipt(txHash).status;
                if (status == 0x1) {
                    console.log("true");

                    res.send("true");

                }
                else if (status == 0x0) {
                    console.log("product already present");
                    res.send("false");
                }
                //res.send(value);
            }

                })
        })
});


app.post('/getProductById', function (req, res) {
    web3.personal.unlockAccount(web3.eth.accounts[0], "1234");
    var productID = parseInt(req.body.productID);
    var details = [];
    //console.log(getDetailsByUserName);
    var value = contractOBJ.getProductById(productID);
    //console.log(value[0]);
    //var resUsername = value[0];
    //var resFirstnamee = value[1];
    let JSONArray = {
        "productID": parseInt(value[0]),
        "productName": web3.toUtf8(value[1]),
        "manufacturerAddress": web3.toUtf8(value[2]),
        "productDescription": web3.toUtf8(value[3]),
        "date": parseInt(value[4]),
        "startTime": parseInt(value[5]),
        "endTime": parseInt(value[6]),
        "kickOffAmount": parseInt(value[7])

    }
    //details.push(n);
    console.log(JSON.stringify(JSONArray));
    res.send(JSON.stringify(JSONArray));
})

// app.get(/getProductById/:productID, function (req, res) //get list of all buyer ID registered
// {
// var value = contract.getProductById.call(productID, { from: unlockAccount() });
// console.log(value);
// res.send(value);
// });
app.post("/submitBid", function (req, res) {
    web3.personal.unlockAccount(web3.eth.accounts[0], "1234");
    var bidAmount = req.body.bidAmount;
    var userName = req.body.userName;
    var productID = req.body.productID;
    let gasValue;


    contractOBJ.submitBid.estimateGas(bidAmount, userName, productID,
        {
            from: web3.eth.accounts[0]
        }, function (err, value) {
            if (err) {
                console.log("Err : ", err)
            }
            else {
                gasValue = value;
                console.log("Gas Value... : ", value)
            }

            contractOBJ.submitBid(bidAmount, userName, productID,
                { from: web3.eth.accounts[0], gas: gasValue }, function (err, value, data)
                //var hash= await contract.createBuyerProfile(buyerID,name,email,location,accountBalance,{from:unlockAccount(),gas:contract.setDetails.estimateGas("name")},function(err,value)
                {
                    if (err) {
                        console.log(err)
                    } else {

                        console.log(value);
                        res.send(value);
                        while (web3.eth.getTransactionReceipt(txHash) == null) {
                            console.log("mining");
                        }
                        console.log("mining completed....")
                        let status = web3.eth.getTransactionReceipt(txHash).status;
                        if (status == 0x1) {
                            console.log("true");
        
                            res.send("true");
        
                        }
                        else if (status == 0x0) {
                            console.log("product already present");
                            res.send("false");
                        }
                    }
                })
        })
})

app.get("/getTopBid", function (req, res) {
    var productID = req.body.productID;
    var value = contractOBJ.getTopBid.call(productID);
    console.log(value);
    res.send(value); // convert it to string using utf8
});

app.post("/sendDepsoit", function (req, res) {

    web3.personal.unlockAccount(web3.eth.accounts[0], "1234");
    var buyerId = req.body.bidAmount;
    var bidAmount = req.body.userName;
    var sellerId = req.body.productID;
    let gasValue;


    contractOBJ.sendDeposit.estimateGas(buyerId, bidAmount, sellerId, { from: web3.eth.accounts[0] }, function (err, value) {
        if (err) {
            console.log("Err :", err)
        }
        else {
            gasValue = value;
            console.log("Gas Value... :", value)
        }

        contractOBJ.sendDeposit(bidAmount, userName, productID,
            { from: web3.eth.accounts[0], gas: gasValue }, function (err, value, data)
            //var hash= await contract.createBuyerProfile(buyerID,name,email,location,accountBalance,{from:unlockAccount(),gas:contract.setDetails.estimateGas("name")},function(err,value)
            {
                if (err) {
                    console.log(err)
                } else {

                    console.log(value);
                    res.send(value);
                }
            })
    })

})


var server = app.listen(8001, (server) => console.log('Server Listening in port 8001'));

console.log(server.address());
