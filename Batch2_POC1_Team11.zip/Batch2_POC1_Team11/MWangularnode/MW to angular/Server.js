const http = require('http');
const express = require('express');
const app = express();
const bodyparser = require('body-parser');
app.use(bodyparser.json());
var port = 4500;
var hostName = "localhost";
var fs = require('fs');

const server = http.createServer(app);
app.use(function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
  res.setHeader('Access-Control-Allow-Credentials', true);
  next();
});




// for buyer page************************************

app.get('/buyer/', function (request, response, next) {
  console.log("in  get js 12");
  // console.log(request.params.data);
  fs.createReadStream('product.json').pipe(response);

})

// for display the specific products for specific people/seller
app.get("/buyer/:data/:data2", (request, response) => {
  // console.log("hi")
  // var user = request.body.userName;
  // var pass = request.body.password;
  var seller = request.params.data;
  var pass = request.params.data2;
  var t=[]; count =0;
  fs.readFile('./product.json', function (err, data) {
    var flag = false; var test = true;
    var ArrayObject = JSON.parse(data);
    if(test=true){
    for (var i = 0; i < ArrayObject.length; i++) {
      if (ArrayObject[i].seller === seller) {
        flag = true; 
        count++;
        t.push(ArrayObject[i]);
      }
    }
    if(count!=0)
    response.status(200).send(t);
    }
    if (count==0) {
      response.status(201).send("Failed");
    }
  });
  //response.end();
});


///for search product************************************

app.get("/buyer/:data", (request, response) => {
  //console.log("in js");
  // var id =request.params.data;  
  //console.log("in products search js");
  var pro = request.params.data;

  if(pro==1){
    fs.readFile('bidamt.json', function (err, data) {
      var ArrayObject = JSON.parse(data);
      var max=ArrayObject[0].amt;
      console.log(max);
      for (var i = 1; i < ArrayObject.length; i++) {
        if (ArrayObject[i].amt >max) { //we can use request.body.productName or pro
          max=ArrayObject[i].amt;
            console.log("condition");
        } else {      }
      }  console.log(max);
      response.status(200).send(max.toString());
  })
  }
  else{
  fs.readFile('product.json', function (err, data) {
    var ArrayObject = JSON.parse(data);

    for (var i = 0; i < ArrayObject.length; i++) {
      if (ArrayObject[i].productName === pro) { //we can use request.body.productName or pro
        var result = ArrayObject[i];
        response.status(200).send(result);
      } else {      }
    }
  });
}
});


// for login authentication************************************
app.get("/login/:data/:data2", (request, response) => {
  // console.log("hi")
  // var user = request.body.userName;
  // var pass = request.body.password;
  var user = request.params.data;
  var pass = request.params.data2;

  fs.readFile('./database.json', function (err, data) {
    var flag = false;
    var ArrayObject = JSON.parse(data);
    for (var i = 0; i < ArrayObject.length; i++) {
      if (ArrayObject[i].password === pass && ArrayObject[i].userName === user) {
        flag = true;
        var t=ArrayObject[i];
        response.status(200).send(t);
      }
    }
    if (flag == false) {
      response.status(201).send("Failed");
    }
  });
  //response.end();
});


// for updating (Product Details) in product-.json********************
app.post('/seller', (request, response) => {
  // console.log(Array);
  console.log("Recently Added Product....",request.body);
  fs.readFile('./product.json', function (err, data) {
    var ArrayObject = JSON.parse(data);
    ArrayObject.push(request.body);
    // console.log(request.body);
    //console.log(ArrayObject);
    var productDetails = JSON.stringify(ArrayObject)
    if (fs.existsSync('./product.json')) {
      fs.writeFile('./product.json', productDetails, 'utf8', (err) => {
        if (err) {
          response.status(201).send("failed");
        } else {
          response.status(200).send("success");
        }
      })
    } else {}
  });
});



// for updating (Biding Amount with personName and ProductName) in bidamt.json************
app.post('/buyer/', (request, response) => {
  console.log("in Biding Amount js");
  fs.readFile('./bidamt.json', function (err, data) {
     var ArrayObject = JSON.parse(data);
     ArrayObject.push(request.body);
     var productDetails = JSON.stringify(ArrayObject);
    if (fs.existsSync('./bidamt.json')) {
      fs.writeFile('./bidamt.json', productDetails, 'utf8', (err) => {
        if (err) {
          response.status(201).send("failed");
        } else {
          response.status(200).send("success");
        }
      })
    } else {}
  });
});



// for updating user details(Registration) in database.json********************
app.post('/signup', (request, response) => {
  // console.log("hi");
  fs.readFile('./database.json', function (err, data) {
    var ArrayObject = JSON.parse(data);
    ArrayObject.push(request.body);
    //console.log(request.body);
    //console.log(ArrayObject);
    var userDetails = JSON.stringify(ArrayObject)
    if (fs.existsSync('./database.json')) {
      fs.writeFile('./database.json', userDetails, 'utf8', (err) => {
        if (err) {
          response.status(201).send("failed");
        } else {
          response.status(200).send("success");
        }
      })
    } else {}
  });
});

//******************************************************************** */


server.listen(port, hostName, () => {
  console.log("Page is hosted in " + port + ' in ' + hostName);
});