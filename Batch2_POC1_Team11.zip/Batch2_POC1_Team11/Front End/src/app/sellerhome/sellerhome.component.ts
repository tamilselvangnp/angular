import { Component, OnInit } from '@angular/core';
import { ProductService } from "../product.service";
import { Router } from "@angular/router";

@Component({
  selector: 'app-sellerhome',
  templateUrl: './sellerhome.component.html',
  styleUrls: ['./sellerhome.component.css']
})
export class SellerhomeComponent implements OnInit {
  welcome:any;
  support:any;
  dataSet:any;
  constructor(public service: ProductService, public route: Router) { }


  // buyer() {
  //   this.service.buyer().subscribe(da => {
  //     this.dataSet=JSON.parse(da);
  //     //  var str=JSON.stringify(da);
  //     //this.dataContainer.nativeElement.innerHTML = da;
  //     this.route.navigate(["/sellerhome"]);
  //   });
  // }

  buyer(welcome,support) {
    this.service.buyer(this.welcome,this.support).subscribe(da => {
      this.dataSet=JSON.parse(da);
      //  var str=JSON.stringify(da);
      //this.dataContainer.nativeElement.innerHTML = da;
      this.route.navigate(["/sellerhome"]);
    });
  }

 
  ngOnInit() {
    this.welcome=localStorage.getItem("welcome");
    this.support="support"
    this.buyer(this.welcome,this.support);
  }

}
