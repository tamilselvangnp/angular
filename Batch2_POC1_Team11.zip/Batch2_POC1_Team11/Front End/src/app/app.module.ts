import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { AppRoutingModule, routingComponents } from "./app-routing.module";
import { AppComponent } from "./app.component";
// import { SignupFormComponent } from './signup-form/signup-form.component';
// import { IndexComponent } from './index/index.component';
// import { HttpClientModule } from "@angular/common/http";
import { HttpModule } from "@angular/http";
import { NavigationComponent } from "./navigation/navigation.component";
import { SellerComponent } from "./seller/seller.component";
import { HomeComponent } from "./home/home.component";
import { LoginService } from "./login.service";
import { UsernavigationComponent } from './usernavigation/usernavigation.component';
import { ProductService } from './product.service';
import { BuyerComponent } from './buyer/buyer.component';
import { SellerhomeComponent } from './sellerhome/sellerhome.component';
import { BuyernavigationComponent } from './buyernavigation/buyernavigation.component';
import { BiddingComponent } from './bidding/bidding.component';
import { BiddingnavComponent } from './biddingnav/biddingnav.component';
import { FooterComponent } from './footer/footer.component';
// import { LoginService } from "./login.service";

@NgModule({
  declarations: [
    AppComponent,
    // SignupFormComponent,
    // IndexComponent,
    routingComponents,
    // HttpClientModule,
    NavigationComponent,
    SellerComponent,
    HomeComponent,
    UsernavigationComponent,
    BuyerComponent,
    SellerhomeComponent,
    BuyernavigationComponent,
    BiddingComponent,
    BiddingnavComponent,
    FooterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [LoginService,ProductService],
  bootstrap: [AppComponent]
  // LoginService
})
export class AppModule {}
