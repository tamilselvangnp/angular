import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buyernav',
  templateUrl: './buyernavigation.component.html',
  styleUrls: ['./buyernavigation.component.css']
})
export class BuyernavigationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
