import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyernavigationComponent } from './buyernavigation.component';

describe('BuyernavigationComponent', () => {
  let component: BuyernavigationComponent;
  let fixture: ComponentFixture<BuyernavigationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BuyernavigationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BuyernavigationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
