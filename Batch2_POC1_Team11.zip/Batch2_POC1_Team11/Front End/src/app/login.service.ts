import { Injectable } from "@angular/core";
import { map } from "rxjs/operators";
import { Http } from "@angular/http";

@Injectable({
  providedIn: "root"
})
export class LoginService {
  constructor(private http: Http) {}

  login1(userName, password) {
    return this.http
      .get("http://localhost:4500/login/" + userName + "/" + password)
      .pipe(
        map(data => {
          return data.text();
        })
      );
  }

  adduser(data) {
    console.log(data);
    return this.http.post("http://localhost:4500/signup/", data).pipe(
      map(data => {
        return data.text();
      })
    );
  }
}
