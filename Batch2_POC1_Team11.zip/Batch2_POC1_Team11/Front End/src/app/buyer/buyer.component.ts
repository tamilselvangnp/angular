import { Component, OnInit } from "@angular/core";
import { ProductService } from "../product.service";
import { Router } from "@angular/router";
// import { ViewChild, ElementRef } from "@angular/core";
// import { SellerComponent } from "../seller/seller.component";
// import { FormGroup } from "@angular/forms";

@Component({
  selector: "app-buyer",
  templateUrl: "./buyer.component.html",
  styleUrls: ["./buyer.component.css"]
})
export class BuyerComponent implements OnInit {
  // @ViewChild("dataContainer") dataContainer: ElementRef;
  // @ViewChild("prodata") prodata: ElementRef;
  dataSet: any;
  dataSet1: any;
  dataSet2: any;
  dataSet3: any;
  highval: any;
  flag: boolean = false;
  fa: boolean = true;
  fb: boolean = false;
  disbidSend: any;
  fs: boolean = false;
  fa1: boolean = true;
  bidcheck:any;

  constructor(public service: ProductService, public route: Router) {}

  buyer() {
    this.service.buyerb().subscribe(da => {
      this.dataSet = JSON.parse(da);
      //  var str=JSON.stringify(da);
      //this.dataContainer.nativeElement.innerHTML = da;
      this.route.navigate(["/buyer"]);
    });
  }

  pro;
  da1;clear;
  search() {
    this.service.search(this.pro).subscribe(da1 => {
      this.dataSet1 = JSON.parse(da1);
      this.fs = true;
      this.fa1 = false;
      if (da1) {
        this.flag = true;
      } else if (da1 === "no") {
        alert("No such Product found");
      }
      this.route.navigate(["/buyer"]);
    });
  }

  welcome;      
  bidamt;
  da3;
  submitbid(bidamt) {
    this.welcome=localStorage.getItem("welcome");
    console.log(bidamt);
    if(bidamt==undefined || this.bidcheck<bidamt)
    {
      alert("Enter the bid amount");
    }
    else {
    this.service.submitbid(
      this.bidamt,this.welcome,this.disbidSend.productName).subscribe(da3 => {
      this.dataSet3 = da3;

      //localStorage.setItem("bidedProduct",this.disbidSend.productName);

      if (da3 == "success") {
        alert("Your Bid Submitted successfully");
        this.tesflag=true;this.high();
      }
      this.route.navigate(["/buyer"]);
    });
    }
  }


  val=1;tesflag=true;
  high(){
    if(this.tesflag==true){ this.tesflag=false;
      this.service.high(this.val).subscribe(da3 => {
        this.highval = da3;
        // console.log("2 nd",this.highval);
        this.bidcheck=this.highval; 
        return this.highval;
      });    
}
}


  back() {
    this.fa1 = true;
    this.fs = false;
  }

  test(disbid) {
    this.fa = !this.fa;
    this.fb = !this.fb;
    this.disbidSend = disbid;
    if (disbid) {
      console.log(disbid.productName);
    }
  }

  ngOnInit() {
    this.buyer();
     //this.high();
    //this.search();
    this.flag;
  }
}
