import { Component, OnInit } from "@angular/core";
import { Session } from 'protractor';

@Component({
  selector: "app-nav",
  templateUrl: "./usernavigation.component.html",
  styleUrls: ["./usernavigation.component.css"]
})
export class UsernavigationComponent implements OnInit {
  constructor() {}
  
// logout(){
//   Session.clear();
// }
  ngOnInit() {}
}
