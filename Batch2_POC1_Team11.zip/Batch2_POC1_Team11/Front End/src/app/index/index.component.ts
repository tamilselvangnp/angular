import { Component, OnInit } from "@angular/core";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { LoginService } from "../login.service";
import { Router } from "@angular/router";

@Component({
  selector: "login",
  templateUrl: "./index.component.html",
  // tslint:disable-next-line: quotemark
  styleUrls: ["./index.component.css"]
})
export class IndexComponent implements OnInit {
  form1;t;
  constructor(public service: LoginService, public route: Router) {}


  userName;
  password;
  login1() {
    console.log(this.form1);
    this.service.login1(this.userName, this.password).subscribe(da => {
      if (da !== "Failed") { 
        this.t=JSON.parse(da);

       localStorage.setItem("welcome",this.t.userName);
       
        this.route.navigate(["/sellerhome"]);
        // need to change the route navigation
      } else {
        alert("please enter valid credentials");
      }
    });
  }

  ngOnInit() {
    this.form1 = new FormGroup({
      userName: new FormControl("", [Validators.required]),
      password: new FormControl("", [Validators.required])
    });
  }
}
