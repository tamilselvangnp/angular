import { Component, OnInit } from "@angular/core";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { LoginService } from "../login.service";

@Component({
  selector: "signup-form",
  templateUrl: "./signup-form.component.html",
  styleUrls: ["./signup-form.component.css"]
})
export class SignupFormComponent implements OnInit {
  // userList: User[] = [];
  submitted = false;
  form: FormGroup;

  adduser() {
    //console.log(form);
    // this.userList.push(this.form.value);
    this.submitted = true;
    if (this.form.invalid) {
      alert("fill Form properly");
      return;
    } else {
      var a = this.form.value;
      //console.log(a);
      this.service.adduser(a).subscribe(data => {
        if (data == "success") {
          console.log("success");
        }
      });
      alert("Registration Successful");
      this.form.reset();
    }
  }

  constructor(public service: LoginService) {}

  //pwdPattern = "^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s).{6,12}$";
  //conformPwdPattern = "^(?=.*d)(?=.*[a-z])(?=.*[A-Z])(?!.*s).{6,12}$";
  mobnumPattern = "^((\\+91-?)|0)?[0-9]{10}$";
  // zipPattern = "^(?[0-9]{6}$";

  ngOnInit() {
    this.form = new FormGroup({
      userName: new FormControl("", [Validators.required]),
      firstName: new FormControl("", [Validators.required]),
      lastName: new FormControl("", [Validators.required]),
      contactAddress: new FormControl("", Validators.required),
      country: new FormControl("", [Validators.required]),
      city: new FormControl("", [Validators.required]),
      walletValue: new FormControl("", [Validators.required]),
      zip: new FormControl("", [Validators.required]),
      phone: new FormControl("", [
        Validators.required,
        Validators.pattern(this.mobnumPattern),
        Validators.minLength(10),
        Validators.maxLength(10)
      ]),
      email: new FormControl("", [Validators.required, Validators.email]),
      password: new FormControl("", [
        Validators.required,
        Validators.pattern(
          "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$"
        )
      ])
      // actionType:new FormControl("", [Validators.required])
      // buyer: new FormControl("", [Validators.required]),
      // seller: new FormControl("", [Validators.required])
      //retype_password: new FormControl("", [Validators.required])
    });
  }
}
