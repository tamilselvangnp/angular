import { AppComponent } from "./app.component";
import { NgModule, Component } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { SignupFormComponent } from "./signup-form/signup-form.component";
import { IndexComponent } from "./index/index.component";
import { SellerComponent } from "./seller/seller.component";
import { HomeComponent } from "./home/home.component";
import {BuyerComponent} from "./buyer/buyer.component";
import { SellerhomeComponent } from "./sellerhome/sellerhome.component";
import { BiddingComponent } from './bidding/bidding.component';

const routes: Routes = [
  { path: "", component: HomeComponent },
  { path: "seller", component: SellerComponent },
  { path: "signup", component: SignupFormComponent },
  { path: "login", component: IndexComponent },
  { path: "buyer", component: BuyerComponent },
  { path: "sellerhome", component: SellerhomeComponent },
  { path: "bidding", component: BiddingComponent }  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
export const routingComponents = [SignupFormComponent, IndexComponent,BuyerComponent,BiddingComponent];
