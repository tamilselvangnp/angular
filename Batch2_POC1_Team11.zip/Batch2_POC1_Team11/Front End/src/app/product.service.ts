import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import { Http, Response } from "@angular/http";

@Injectable({
  providedIn: "root"
})
export class ProductService {
  constructor(private http: Http) {}

  addProduct(data) {
    console.log(data);
    return this.http.post("http://localhost:4500/seller", data).pipe(
      map(data => {
        return data.text();
      })
    );
  }

  //**************************************************
  buyerb() {
    // console.log("in products service");
    return this.http.get("http://localhost:4500/buyer/").pipe(
      map(data => {
        return data.text();
      })
    );
  }


  buyer(seller,support) {
    // console.log("in products service");
    return this.http.get("http://localhost:4500/buyer/"+ seller + "/" + support).pipe(
      map(data => {
        return data.text();
      })
    );
  }
  //**************************************************

  search(pro) {
    return this.http.get("http://localhost:4500/buyer/" + pro).pipe(
      map(data => {
        return data.text();
      })
    );
  }
  //**************************************************
  

  submitbid(bidamt,welcome,productName) {
    console.log("in service");
    var obj = {"amt" : bidamt ,"userName": welcome,"productName":productName};
    console.log(bidamt);
    return this.http.post("http://localhost:4500/buyer", obj).pipe(
      map(data => {
        return data.text();
      })
    );
  }
//**************************************************

  high(test) {
    console.log("in service",test);
    return this.http.get("http://localhost:4500/buyer/"+test).pipe(
      map(data => {
        console.log("in service",data);
        return data.json();
      })
    );
  }
//**************************************************
}
