import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from "@angular/forms";
import {ProductService} from "../product.service";
import { runInThisContext } from 'vm';


@Component({
  selector: 'seller',
  templateUrl: './seller.component.html',
  styleUrls: ['./seller.component.css']
})
export class SellerComponent implements OnInit {
  seller:any;
  submitted = false;
  form2: FormGroup;

  addProduct() {
    console.log("Seller Works");

    this.submitted = true;
    if (this.form2.invalid){
      alert("Fill product details properly");
      return;
    }
    else
    {
      var a = this.form2.value;
      // console.log(a);
      this.service.addProduct(a).subscribe(data =>{
              if(data=="success")
              {  console.log("success");  }
      })
      alert("Product added Successful");
      this.form2.reset();
    }
  };

  constructor(public service:ProductService) { }

  ngOnInit() {
    this.seller=localStorage.getItem("welcome");
    console.log(this.seller);
    this.form2 = new FormGroup({
      productName: new FormControl("", [Validators.required]),
      productId: new FormControl("", [Validators.required]),
      address: new FormControl("", [Validators.required]),
      productDescription: new FormControl("", [Validators.required]),
      date: new FormControl("", Validators.required),
      startTime: new FormControl("", [Validators.required]),
      endTime: new FormControl("", [Validators.required]),
      kickoffAmount: new FormControl("", [Validators.required]),
      seller: new FormControl("")
    });
  }

}