import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-biddingnav',
  templateUrl: './biddingnav.component.html',
  styleUrls: ['./biddingnav.component.css']
})
export class BiddingnavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
