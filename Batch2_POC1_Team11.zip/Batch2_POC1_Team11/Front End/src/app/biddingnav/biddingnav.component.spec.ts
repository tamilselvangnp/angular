import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BiddingnavComponent } from './biddingnav.component';

describe('BiddingnavComponent', () => {
  let component: BiddingnavComponent;
  let fixture: ComponentFixture<BiddingnavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BiddingnavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BiddingnavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
