import { Component, OnInit } from '@angular/core';
import { AuthorizationService } from 'src/app/authorization.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  update:FormGroup;
  constructor(private service:AuthorizationService,private router:Router) { 


}

  ngOnInit() {
    this.update=new FormGroup({
      name: new FormControl(localStorage.getItem("name")),
      branch:new FormControl(localStorage.getItem("branch")),
      marks:new FormControl(localStorage.getItem("marks"))
       
        });
  }


  updateDetails()
  {
    console.log(this.update.value);
    var data=this.update.value;
    this.service.update(data).subscribe(res=>{
      console.log(res);
      if(res["success"]==true)
      {
        alert("Updated Successfully");
        this.router.navigate(['/dash']);
      }
    })
  }
}
