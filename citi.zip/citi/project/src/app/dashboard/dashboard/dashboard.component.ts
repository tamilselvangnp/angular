import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthorizationService } from 'src/app/authorization.service';
import {  Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  stuForm;
  name;
  arrayDetails;
  constructor(private service:AuthorizationService,private router:Router) {
    this.stuForm = new FormGroup({
      name: new FormControl("", [Validators.required]),
      branch: new FormControl("", [Validators.required]),
      mark: new FormControl("", [Validators.required])
    });


  }

  ngOnInit() {
    this.view();
  }
  view()
  {
    // localStorage.setItem('name',name)
  this.name=localStorage.getItem("name");
  console.log("fhjskjw",this.name)
    this.service.viewdetails(this.name).subscribe(res=>{
      console.log("view ts ..",res);
 
      this.arrayDetails=res;
      console.log(this.arrayDetails);

    })

  }
  update(branch,marks) 
{
 
  localStorage.setItem("branch", branch);
  localStorage.setItem("marks", marks);
  this.router.navigate(['/update']);
}
logout(){  this.service.logout() }
}
