import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl,Validators} from '@angular/forms';
import { Router, NavigationExtras } from '@angular/router';
import { AuthorizationService } from '../../authorization.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  form1;
  data;
  name;
  constructor(public route: Router, private auth: AuthorizationService) { }

  ngOnInit() {
    this.form1 = new FormGroup({
      name: new FormControl("", [Validators.required]),
      password: new FormControl("", [Validators.required])
    });
  }

  login1(){
    this.data=this.form1.value.name;
    // console.log("hsjdh",this.data)
  this.auth.Login(this.form1.value).subscribe(data => {
    if(data['msg']=='success'){
    localStorage.setItem("name",this.data)
      this.route.navigate(['/dash']); 
    }
    else
      alert("Try again")
  });
  }

  // logout(){  this.auth.logout() }
}
