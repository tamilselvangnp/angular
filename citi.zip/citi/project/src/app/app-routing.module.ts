import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AuthGuard } from './authguard';
import { LoginComponent } from './login/login/login.component';

const routes: Routes = [
  // { path: "", component: LoginComponent },
  {
    path: 'dash',
    loadChildren: 'src/app/dashboard/dashboard.module#DashboardModule', 
    canActivate: [AuthGuard]
  },
  {
    path: 'update',
    loadChildren: 'src/app/update/update.module#UpdateModule',
    canActivate: [AuthGuard]
  },
  {
    path: 'login',
    loadChildren: 'src/app/login/login.module#LoginModule'
  },
   // otherwise redirect to login
   { path: '**', redirectTo: 'login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
