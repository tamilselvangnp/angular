import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthorizationService {
  user: any;
  constructor(private http: HttpClient, private router: Router) { }

  isLoggedin(): boolean {
    // this.user &&
    if ( localStorage.getItem('currentUser')) {
        return true;
    } else {
        return false;
    }
}

logout(){
    console.log("logged out")
    localStorage.removeItem('currentUser');
}



Login(loginData: { username: string; password: string; }): Observable<any> {
    return this.http.post<{ token: string}>('http://localhost:4500/login', loginData).pipe(
        map(data => {
            localStorage.setItem('currentUser', data.token);
            console.log(data.token, 'data token');
            this.user = data.token;
            return data;
        })
    );
}


viewdetails(name)
{
    console.log("data from service",name)
    return this.http.get('http://localhost:4500/view/'+name)
}
update(data)
{
    console.log("update data from service",data)
    return this.http.put('http://localhost:4500/update',data)
}

}
