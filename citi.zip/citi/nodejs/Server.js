const http = require('http');
const express = require('express');
const app = express();
const bodyparser = require('body-parser');
app.use(bodyparser.json());
var port = 4500;
var hostName = "localhost";
var fs = require('fs');
const jwt = require('jsonwebtoken');
const server = http.createServer(app);

app.use(function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
  res.setHeader('Access-Control-Allow-Credentials', true);
  next();
});

// for login *************************************************
const JWT_Secret = 'your_secret_key'; 
app.post("/login", (request, response) => {
  var user = request.body;
  console.log("user : ",request.body.name,"pass : ",request.body.password)
  fs.readFile('./database.json', function (err, data) {
    var flag = false;
    var ArrayObject = JSON.parse(data);
    for (var i = 0; i < ArrayObject.length; i++) {
      if (ArrayObject[i].password === request.body.password &&
         ArrayObject[i].name === request.body.name) {
        flag = true;
        var token = jwt.sign(user, JWT_Secret);
        response.status(200).send({
          signed_user: user,
          token: token,
          msg:"success"
        });
        // response.status(200).send({msg:"success"});
      }
    }
    if (flag == false) {
      response.status(201).send({msg:"failed"});
    }
  });
});
// // for get all details from the file *************************
app.get('/view/:data', (req,res)=>{
  console.log(req.params.data);
var name = req.params.data;
console.log("name",name)
  fs.readFile('./userDetails.json',function(err,data){
      if(err){
          throw err;
      }
      var temp=JSON.parse(data);
      var array=[];
      console.log("reading data ",temp);
      for(var i=0;i<temp.length;i++){
         if(temp[i].name==name) {    
          console.log("inside if");
          console.log("Details Matched");
          console.log(temp[i]);
          array.push(temp[i]);
         return res.send(temp[i]);
        }
   
      }
      res.send({"success":false})
      })
});

///for Update Details ****************************************
app.put('/update',function(req,res){
  console.log(req);
  var name=req.body.name;
  var branch=req.body.branch;
  var marks=req.body.marks;
    fs.readFile('./userDetails.json',function(err,data){
      if(err)
      {
          throw err;
      }
      var temp=JSON.parse(data);
      console.log(temp);
      for(var i=0;i<temp.length;i++)
      {
          if(temp[i].name==name)
          {
              temp[i].branch=branch;
              temp[i].marks=marks;
              break;
          }
                 
      }
      fs.writeFile('./userDetails.json',JSON.stringify(temp),function(err){
          if(err)
          {
              throw err;
          }
          return res.send({"success":true});
      })   
    })
});

server.listen(port, hostName, () => {
  console.log("Page is hosted in " + port + ' in ' + hostName);
});


