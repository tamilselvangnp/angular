const http = require('http');
const express = require('express');
const app = express();
const bodyparser = require('body-parser');
app.use(bodyparser.json());
var port = 4500;
var hostName = "localhost";
var fs = require('fs');

const server = http.createServer(app);
app.use(function (req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
  res.setHeader('Access-Control-Allow-Credentials', true);
  next();
});




// for buyer page************************************

app.get('/buyer/', function (request, response, next) {
  console.log("in  get js");

  //console.log("in products js");
  fs.createReadStream('product.json').pipe(response);
})


///for search product************************************

app.get("/buyer/:data", (request, response) => {
  //console.log("in js");
  // var id =request.params.data;  
  //console.log("in products search js");
  var pro = request.params.data;
  // console.log("fedf", request.body.productName)
  fs.readFile('product.json', function (err, data) {
    var ArrayObject = JSON.parse(data);

    for (var i = 0; i < ArrayObject.length; i++) {
      if (ArrayObject[i].productName === pro) { //we can use request.body.productName or pro
        var result = ArrayObject[i];
        response.status(200).send(result);
      } else {
        //var result="no";
        //response.status(200).send(result);
        //response.send(result);
        //response.status(200).send(ArrayObject[0]);
      }
    }
  });
});





// for login authentication************************************
app.get("/login/:data/:data2", (request, response) => {
  // console.log("hi")
  // var user = request.body.userName;
  // var pass = request.body.password;
  var user = request.params.data;
  var pass = request.params.data2;

  // res.status(200).send({add:data1+data2});
  // console.log("user : ",user,"pass : ",pass)
  fs.readFile('./database.json', function (err, data) {
    var flag = false;
    var ArrayObject = JSON.parse(data);
    //response.status(200).send(ArrayObject);
    //ArrayObject.push(request.body);
    for (var i = 0; i < ArrayObject.length; i++) {
      // console.log("passw : ",ArrayObject[i].password)
      if (ArrayObject[i].password === pass && ArrayObject[i].userName === user) {
        flag = true;
        response.status(200).send("success");
      }
    }
    if (flag == false) {
      response.status(201).send("Failed");
    }
  });
  //response.end();
});


// for updating (Product Details) in product-.json********************
app.post('/seller', (request, response) => {
  // console.log(Array);
  fs.readFile('./product.json', function (err, data) {
    var ArrayObject = JSON.parse(data);
    ArrayObject.push(request.body);
    // console.log(request.body);
    console.log(ArrayObject);
    var productDetails = JSON.stringify(ArrayObject)
    if (fs.existsSync('./product.json')) {
      fs.writeFile('./product.json', productDetails, 'utf8', (err) => {
        if (err) {
          response.status(201).send("failed");
        } else {
          response.status(200).send("success");
        }
      })
    } else {}
  });
});



// for updating (Biding Amount) in bidamt.json********************
app.post('/buyer', (request, response) => {
  console.log("in Biding Amount js");
  fs.readFile('./bidamt.json', function (err, data) {
    // var ArrayObject = JSON.parse(data);
    var ArrayObject = [];
    ArrayObject = data;
    ArrayObject.push(request.body);
    // console.log(request.body);
    console.log(ArrayObject);
    var productDetails = JSON.stringify(ArrayObject)
    if (fs.existsSync('./bidamt.json')) {
      fs.writeFile('./bidamt.json', productDetails, 'utf8', (err) => {
        if (err) {
          response.status(201).send("failed");
        } else {
          response.status(200).send("success");
        }
      })
    } else {}
  });
});



// for updating user details(Registration) in database.json********************
app.post('/signup', (request, response) => {
  // console.log("hi");
  console.log(Array);
  fs.readFile('./database.json', function (err, data) {
    var ArrayObject = JSON.parse(data);
    ArrayObject.push(request.body);
    // console.log(request.body);
    console.log(ArrayObject);
    var userDetails = JSON.stringify(ArrayObject)
    if (fs.existsSync('./database.json')) {
      fs.writeFile('./database.json', userDetails, 'utf8', (err) => {
        if (err) {
          response.status(201).send("failed");
        } else {
          response.status(200).send("success");
        }
      })
    } else {}
  });
});

//******************************************************************** */


server.listen(port, hostName, () => {
  console.log("Page is hosted in " + port + ' in ' + hostName);
});